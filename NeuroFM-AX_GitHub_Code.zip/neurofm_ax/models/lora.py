"""
models/lora.py
--------------
Low-Rank Adaptation (LoRA) for the 3D Vision Transformer backbone.

Implements Hu et al. (2022) LoRA: h = W₀x + (α/r)·BAx
  - W₀ ∈ ℝ^(k×d) is frozen
  - A ∈ ℝ^(r×d), initialised ~ N(0, σ²)
  - B ∈ ℝ^(k×r), initialised to 0  →  ΔW = 0 at start of training

Hyperparameters used in the paper:
  rank  r = 8
  alpha α = 16
  target modules: Wq, Wv, MLP_fc1, MLP_fc2

Total trainable parameters: ~0.52 M  (0.605% of the 86 M backbone)
"""

from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


# ──────────────────────────────────────────────────────────────────────────────
# LoRA linear layer
# ──────────────────────────────────────────────────────────────────────────────

class LoRALinear(nn.Module):
    """
    Drop-in replacement for nn.Linear with a frozen base weight and a
    trainable low-rank adapter.

    Parameters
    ----------
    base_layer : nn.Linear  – the pre-trained weight (will be frozen)
    rank       : int         – LoRA rank r
    alpha      : float       – scaling factor α  (scale = α / r)
    """

    def __init__(
        self,
        base_layer: nn.Linear,
        rank: int = 8,
        alpha: float = 16.0,
    ) -> None:
        super().__init__()

        self.in_features  = base_layer.in_features
        self.out_features = base_layer.out_features
        self.rank  = rank
        self.alpha = alpha
        self.scale = alpha / rank

        # Freeze the original weight
        self.weight = nn.Parameter(base_layer.weight.data.clone(), requires_grad=False)
        if base_layer.bias is not None:
            self.bias = nn.Parameter(base_layer.bias.data.clone(), requires_grad=False)
        else:
            self.bias = None

        # Trainable low-rank matrices
        # A ~ N(0, 1/r),  B = 0  →  ΔW = BA = 0 at init
        self.lora_A = nn.Parameter(
            torch.empty(rank, self.in_features).normal_(0, 1 / math.sqrt(rank))
        )
        self.lora_B = nn.Parameter(torch.zeros(self.out_features, rank))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        base_out = F.linear(x, self.weight, self.bias)
        lora_out = F.linear(F.linear(x, self.lora_A), self.lora_B) * self.scale
        return base_out + lora_out

    def extra_repr(self) -> str:
        return (
            f"in={self.in_features}, out={self.out_features}, "
            f"rank={self.rank}, alpha={self.alpha}, scale={self.scale:.4f}"
        )


# ──────────────────────────────────────────────────────────────────────────────
# Injection utilities
# ──────────────────────────────────────────────────────────────────────────────

def inject_lora(
    model: nn.Module,
    target_modules: list[str],
    rank: int = 8,
    alpha: float = 16.0,
    verbose: bool = True,
) -> nn.Module:
    """
    Replace all nn.Linear layers whose name contains any string in
    `target_modules` with LoRALinear layers.

    Example
    -------
    inject_lora(vit, target_modules=["attn_q", "attn_v", "mlp_fc1", "mlp_fc2"])
    """
    replaced = 0
    for name, module in list(model.named_modules()):
        # Identify parent module and attribute name
        parts = name.split(".")
        if len(parts) == 0:
            continue

        attr = parts[-1]
        if not any(t in attr for t in target_modules):
            continue
        if not isinstance(module, nn.Linear):
            continue

        # Navigate to parent
        parent = model
        for part in parts[:-1]:
            parent = getattr(parent, part)

        lora_layer = LoRALinear(module, rank=rank, alpha=alpha)
        setattr(parent, attr, lora_layer)
        replaced += 1

        if verbose:
            print(f"  LoRA injected: {name}  [{module.in_features}→{module.out_features}]")

    if verbose:
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(
            f"\nTotal params: {total_params/1e6:.2f} M  |  "
            f"Trainable: {trainable_params/1e6:.3f} M  "
            f"({100*trainable_params/total_params:.3f}%)  |  "
            f"LoRA layers replaced: {replaced}"
        )

    return model


def freeze_backbone(model: nn.Module) -> nn.Module:
    """Freeze all parameters that are not part of a LoRALinear adapter."""
    for name, param in model.named_parameters():
        if "lora_A" in name or "lora_B" in name:
            param.requires_grad = True
        else:
            param.requires_grad = False
    return model


def get_lora_state_dict(model: nn.Module) -> dict[str, torch.Tensor]:
    """Return only the LoRA adapter weights (for compact checkpointing)."""
    return {
        name: param
        for name, param in model.state_dict().items()
        if "lora_A" in name or "lora_B" in name
    }


def merge_lora_weights(model: nn.Module) -> nn.Module:
    """
    Merge LoRA adapters into the base weights in-place (for inference efficiency).
    After merging, LoRALinear behaves identically to a standard nn.Linear.
    """
    for module in model.modules():
        if isinstance(module, LoRALinear):
            delta = (module.lora_B @ module.lora_A) * module.scale
            module.weight.data += delta
            module.lora_A.data.zero_()
            module.lora_B.data.zero_()
    return model


# ──────────────────────────────────────────────────────────────────────────────
# Parameter count helpers
# ──────────────────────────────────────────────────────────────────────────────

def count_parameters(model: nn.Module) -> dict[str, int]:
    """Return total, trainable, and frozen parameter counts."""
    total     = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    frozen    = total - trainable
    return {"total": total, "trainable": trainable, "frozen": frozen}


def print_trainable_parameters(model: nn.Module) -> None:
    counts = count_parameters(model)
    pct = 100 * counts["trainable"] / max(counts["total"], 1)
    print(
        f"Trainable : {counts['trainable']:>12,}  ({pct:.3f}%)\n"
        f"Frozen    : {counts['frozen']:>12,}\n"
        f"Total     : {counts['total']:>12,}"
    )
