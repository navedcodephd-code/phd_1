"""
models/vit3d.py
---------------
3D Vision Transformer (ViT-Base) backbone for NeuroFM-AX.

Architecture:
  L = 12 transformer blocks
  d = 768 hidden dimension
  12 attention heads
  MLP ratio = 4  →  FFN dim = 3072
  Total params: ~86 M
  Input: concatenated multi-modal tokens (ROI + global)

Pre-norm architecture (LayerNorm before each sub-layer).
Residual connections follow the standard ViT design (Fig. 2a of the paper).
"""

from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


# ──────────────────────────────────────────────────────────────────────────────
# Multi-Head Self-Attention
# ──────────────────────────────────────────────────────────────────────────────

class MultiHeadSelfAttention(nn.Module):
    def __init__(self, dim: int = 768, num_heads: int = 12, dropout: float = 0.0) -> None:
        super().__init__()
        assert dim % num_heads == 0
        self.num_heads = num_heads
        self.head_dim  = dim // num_heads
        self.scale     = self.head_dim ** -0.5

        # Named to match LoRA target_modules in config
        self.attn_q = nn.Linear(dim, dim, bias=True)
        self.attn_k = nn.Linear(dim, dim, bias=True)
        self.attn_v = nn.Linear(dim, dim, bias=True)
        self.proj   = nn.Linear(dim, dim, bias=True)
        self.drop   = nn.Dropout(dropout)

    def forward(
        self,
        x: torch.Tensor,                         # (B, N, d)
        attn_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        B, N, d = x.shape
        H, Dh = self.num_heads, self.head_dim

        q = self.attn_q(x).view(B, N, H, Dh).transpose(1, 2)  # (B,H,N,Dh)
        k = self.attn_k(x).view(B, N, H, Dh).transpose(1, 2)
        v = self.attn_v(x).view(B, N, H, Dh).transpose(1, 2)

        attn = (q @ k.transpose(-2, -1)) * self.scale          # (B,H,N,N)
        if attn_mask is not None:
            attn = attn + attn_mask
        attn = self.drop(F.softmax(attn, dim=-1))

        out = (attn @ v).transpose(1, 2).reshape(B, N, d)      # (B,N,d)
        return self.proj(out)


# ──────────────────────────────────────────────────────────────────────────────
# Feed-Forward MLP
# ──────────────────────────────────────────────────────────────────────────────

class MLP(nn.Module):
    def __init__(self, dim: int = 768, mlp_ratio: float = 4.0, dropout: float = 0.0) -> None:
        super().__init__()
        hidden = int(dim * mlp_ratio)
        # Named to match LoRA target_modules
        self.mlp_fc1 = nn.Linear(dim, hidden)
        self.mlp_fc2 = nn.Linear(hidden, dim)
        self.act     = nn.GELU()
        self.drop    = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.drop(self.mlp_fc2(self.drop(self.act(self.mlp_fc1(x)))))


# ──────────────────────────────────────────────────────────────────────────────
# Transformer Block (pre-norm)
# ──────────────────────────────────────────────────────────────────────────────

class TransformerBlock(nn.Module):
    """
    Pre-norm Transformer block (Eq. 2 in the paper):
      z' = MHSA(LN(z^{l-1})) + z^{l-1}
      z  = MLP(LN(z')) + z'
    """

    def __init__(
        self,
        dim: int = 768,
        num_heads: int = 12,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn  = MultiHeadSelfAttention(dim, num_heads, dropout)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp   = MLP(dim, mlp_ratio, dropout)

    def forward(
        self,
        x: torch.Tensor,
        attn_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        x = x + self.attn(self.norm1(x), attn_mask)
        x = x + self.mlp(self.norm2(x))
        return x


# ──────────────────────────────────────────────────────────────────────────────
# Modality + Positional Embeddings
# ──────────────────────────────────────────────────────────────────────────────

class ModalityEmbedding(nn.Module):
    """Learnable modality-type embedding added to every token of that modality."""

    def __init__(self, num_modalities: int, dim: int = 768) -> None:
        super().__init__()
        self.emb = nn.Embedding(num_modalities, dim)

    def forward(self, modality_ids: torch.Tensor) -> torch.Tensor:
        """modality_ids : (B, N) LongTensor"""
        return self.emb(modality_ids)


# ──────────────────────────────────────────────────────────────────────────────
# 3D ViT-Base Encoder
# ──────────────────────────────────────────────────────────────────────────────

class ViT3D(nn.Module):
    """
    3D Vision Transformer encoder for NeuroFM-AX.

    Accepts pre-tokenised token embeddings from the anatomy-aware tokenizer
    (models/tokenizer.py) together with their positional and modality
    embeddings, and returns contextualised token representations.

    Parameters
    ----------
    dim           : hidden dimension (768)
    num_layers    : number of transformer blocks (12)
    num_heads     : attention heads (12)
    mlp_ratio     : FFN expansion factor (4.0)
    num_modalities: number of input modalities (4: T1, FLAIR, NM-MRI, DAT-SPECT)
    max_tokens    : maximum total token count per scan (used for pos. embedding)
    dropout       : dropout rate (0.0 during pretraining, 0.1 during fine-tuning)
    """

    def __init__(
        self,
        dim: int = 768,
        num_layers: int = 12,
        num_heads: int = 12,
        mlp_ratio: float = 4.0,
        num_modalities: int = 4,
        max_tokens: int = 6450,   # 12 ROI + ~1600 global × 4 modalities
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.dim = dim

        # [CLS] token
        self.cls_token = nn.Parameter(torch.zeros(1, 1, dim))

        # Learnable 3-D positional embedding
        self.pos_embed = nn.Parameter(torch.zeros(1, max_tokens + 1, dim))

        # Modality-type embedding
        self.mod_embed = ModalityEmbedding(num_modalities, dim)

        # Transformer blocks
        self.blocks = nn.ModuleList([
            TransformerBlock(dim, num_heads, mlp_ratio, dropout)
            for _ in range(num_layers)
        ])
        self.norm = nn.LayerNorm(dim)
        self.drop = nn.Dropout(dropout)

        self._init_weights()

    def _init_weights(self) -> None:
        nn.init.trunc_normal_(self.cls_token,  std=0.02)
        nn.init.trunc_normal_(self.pos_embed,  std=0.02)

    def forward(
        self,
        token_embeds: torch.Tensor,              # (B, N, d)  from tokenizer
        modality_ids: torch.Tensor,              # (B, N) LongTensor
        visible_mask: Optional[torch.Tensor] = None,  # (B, N) bool – for MVM
    ) -> torch.Tensor:
        """
        Parameters
        ----------
        token_embeds : patch projections from the anatomy-aware tokenizer
        modality_ids : integer modality index for each token
        visible_mask : if provided, only forward visible (unmasked) tokens

        Returns
        -------
        hidden : (B, N_vis+1, d)  where [0] is the [CLS] token
        """
        B, N, _ = token_embeds.shape

        # Add modality embeddings
        x = token_embeds + self.mod_embed(modality_ids)

        # Filter to visible tokens (MVM masking)
        if visible_mask is not None:
            # visible_mask: (B, N) True = keep
            # Gather visible tokens per sample (variable length → pad-and-mask)
            x = self._apply_mask(x, visible_mask)
            N = x.shape[1]

        # Prepend [CLS]
        cls = self.cls_token.expand(B, -1, -1)
        x   = torch.cat([cls, x], dim=1)         # (B, N+1, d)

        # Add positional embedding (truncate / interpolate if needed)
        pos = self.pos_embed[:, :N + 1, :]
        x   = self.drop(x + pos)

        # Transformer blocks
        for block in self.blocks:
            x = block(x)

        return self.norm(x)

    @staticmethod
    def _apply_mask(x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """
        Zero-out masked tokens and return (packed) visible tokens.
        For simplicity, returns zeroed tokens; the decoder attends only to
        non-zero positions via the mask.
        """
        return x * mask.unsqueeze(-1).float()

    @property
    def cls_hidden(self) -> None:
        """Access via forward output[:,0,:] after calling forward()."""
        ...


# ──────────────────────────────────────────────────────────────────────────────
# Factory
# ──────────────────────────────────────────────────────────────────────────────

def vit3d_base(**kwargs) -> ViT3D:
    """ViT-Base: L=12, d=768, 12 heads, ~86 M params."""
    defaults = dict(dim=768, num_layers=12, num_heads=12, mlp_ratio=4.0)
    defaults.update(kwargs)
    return ViT3D(**defaults)


if __name__ == "__main__":
    # Quick parameter count
    model = vit3d_base()
    total = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"ViT-3D-Base  total params: {total:.1f} M")
