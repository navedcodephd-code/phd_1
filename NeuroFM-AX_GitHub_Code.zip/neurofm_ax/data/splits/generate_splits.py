"""
data/splits/generate_splits.py
-------------------------------
Generates stratified patient-level train / val / test splits for the
418-subject PPMI four-class cohort (HC=122, PD=148, Prodromal=84, SWEDD=64).

Stratification axes: class label, sex (M/F), acquisition site.
Target counts  : train 274 / val 69 / test 75  (≈ 65/17/18 %)

The script writes one JSON file per seed (42, 17, 2024).  Each file maps
  { "train": [subj_id, ...], "val": [...], "test": [...] }

Usage
-----
  python generate_splits.py --cohort_csv ppmi_subjects.csv --out_dir .

The cohort CSV must have columns:
  subject_id, label (HC|PD|Prodromal|SWEDD), sex (M|F), site
"""

from __future__ import annotations

import argparse
import json
import random
from collections import defaultdict
from pathlib import Path


SEEDS = [42, 17, 2024]

# Target fractions (subject-level)
TRAIN_FRAC = 274 / 418
VAL_FRAC   =  69 / 418
# TEST_FRAC  =  75 / 418  (remainder)

CLASSES = ["HC", "PD", "Prodromal", "SWEDD"]
CLASS_COUNTS = {"HC": 122, "PD": 148, "Prodromal": 84, "SWEDD": 64}
# Per-class target splits (from Table 2 in the paper)
TARGET = {
    "HC":       {"train": 80,  "val": 20, "test": 22},
    "PD":       {"train": 96,  "val": 24, "test": 28},
    "Prodromal":{"train": 56,  "val": 14, "test": 14},
    "SWEDD":    {"train": 42,  "val": 11, "test": 11},
}


def load_cohort(csv_path: Path) -> dict[str, list[dict]]:
    """Return dict mapping class label → list of subject dicts."""
    import csv
    subjects_by_class: dict[str, list[dict]] = defaultdict(list)
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            subjects_by_class[row["label"]].append(
                {"id": row["subject_id"], "sex": row["sex"], "site": row["site"]}
            )
    return subjects_by_class


def stratified_split_class(
    subjects: list[dict],
    n_train: int,
    n_val: int,
    n_test: int,
    rng: random.Random,
) -> tuple[list[str], list[str], list[str]]:
    """
    Stratify within one class by sex × site cells, then allocate to
    train / val / test proportionally from each cell.
    """
    assert len(subjects) == n_train + n_val + n_test, (
        f"Expected {n_train+n_val+n_test} subjects, got {len(subjects)}"
    )

    # Group by sex × site cell
    cells: dict[tuple, list[dict]] = defaultdict(list)
    for s in subjects:
        cells[(s["sex"], s["site"])].append(s)

    train_ids, val_ids, test_ids = [], [], []

    # First pass: proportional allocation per cell
    for (sex, site), cell_subjs in cells.items():
        rng.shuffle(cell_subjs)
        total = len(cell_subjs)
        cell_n_train = round(total * n_train / len(subjects))
        cell_n_val   = round(total * n_val   / len(subjects))
        cell_n_test  = total - cell_n_train - cell_n_val
        # Keep cell_n_test ≥ 0
        if cell_n_test < 0:
            cell_n_val += cell_n_test
            cell_n_test = 0

        train_ids += [s["id"] for s in cell_subjs[:cell_n_train]]
        val_ids   += [s["id"] for s in cell_subjs[cell_n_train:cell_n_train+cell_n_val]]
        test_ids  += [s["id"] for s in cell_subjs[cell_n_train+cell_n_val:]]

    # Second pass: trim / top-up to exact target counts
    all_remaining = list(
        set(s["id"] for s in subjects)
        - set(train_ids) - set(val_ids) - set(test_ids)
    )
    rng.shuffle(all_remaining)

    def trim_topup(lst, target, pool):
        while len(lst) > target:
            pool.append(lst.pop())
        while len(lst) < target and pool:
            lst.append(pool.pop())

    pool = all_remaining
    trim_topup(test_ids,  n_test,  pool)
    trim_topup(val_ids,   n_val,   pool)
    train_ids += pool  # remainder goes to train

    assert len(train_ids) == n_train, f"train mismatch: {len(train_ids)} vs {n_train}"
    assert len(val_ids)   == n_val,   f"val   mismatch: {len(val_ids)}   vs {n_val}"
    assert len(test_ids)  == n_test,  f"test  mismatch: {len(test_ids)}  vs {n_test}"

    return train_ids, val_ids, test_ids


def generate_split(
    subjects_by_class: dict[str, list[dict]],
    seed: int,
    out_path: Path,
) -> None:
    rng = random.Random(seed)
    train_all, val_all, test_all = [], [], []

    for cls in CLASSES:
        subjs = list(subjects_by_class[cls])
        t = TARGET[cls]
        tr, va, te = stratified_split_class(
            subjs, t["train"], t["val"], t["test"], rng
        )
        train_all += tr
        val_all   += va
        test_all  += te

    # Shuffle within each split (seed-controlled)
    rng.shuffle(train_all)
    rng.shuffle(val_all)
    rng.shuffle(test_all)

    split_data = {
        "seed":  seed,
        "n_train": len(train_all),
        "n_val":   len(val_all),
        "n_test":  len(test_all),
        "train": train_all,
        "val":   val_all,
        "test":  test_all,
    }

    out_path.write_text(json.dumps(split_data, indent=2))
    print(
        f"Seed {seed}: train={len(train_all)} val={len(val_all)} "
        f"test={len(test_all)} → {out_path}"
    )


def verify_split(split_path: Path, subjects_by_class: dict[str, list[dict]]) -> None:
    """Sanity-check: no subject-level leakage across partitions."""
    data = json.loads(split_path.read_text())
    train_set = set(data["train"])
    val_set   = set(data["val"])
    test_set  = set(data["test"])

    assert train_set.isdisjoint(val_set),   "LEAKAGE: train ∩ val ≠ ∅"
    assert train_set.isdisjoint(test_set),  "LEAKAGE: train ∩ test ≠ ∅"
    assert val_set.isdisjoint(test_set),    "LEAKAGE: val ∩ test ≠ ∅"

    all_ids = set(s["id"] for cls in subjects_by_class.values() for s in cls)
    assert train_set | val_set | test_set == all_ids, "Not all subjects accounted for"

    print(f"  ✓ No leakage in {split_path.name}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort_csv", required=True, help="Path to ppmi_subjects.csv")
    parser.add_argument("--out_dir", default=".", help="Output directory for split JSONs")
    args = parser.parse_args()

    cohort_csv = Path(args.cohort_csv)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    subjects_by_class = load_cohort(cohort_csv)
    for cls in CLASSES:
        n = len(subjects_by_class[cls])
        expected = CLASS_COUNTS[cls]
        assert n == expected, f"{cls}: expected {expected} subjects, found {n}"
        print(f"  {cls}: {n} subjects loaded")

    for seed in SEEDS:
        out_path = out_dir / f"ppmi_splits_seed{seed}.json"
        generate_split(subjects_by_class, seed, out_path)
        verify_split(out_path, subjects_by_class)

    print("\nAll splits generated and verified.")


if __name__ == "__main__":
    main()
