"""
training/finetune.py
---------------------
Stage 2: LoRA fine-tuning of the frozen NeuroFM-AX backbone on the
PPMI four-class task (HC / PD / Prodromal / SWEDD).

Usage
-----
  # Standard fine-tuning (single seed, produces Table 7 test row)
  python training/finetune.py --config configs/finetune.yaml --seed 42

  # 10-fold CV (for Table 7 CV mean ± SD)
  python training/finetune.py --config configs/finetune.yaml --seed 42 --cv

  # Eval-only on the held-out test set (run exactly once)
  python training/finetune.py --config configs/finetune.yaml \
      --eval_only --checkpoint checkpoints/finetune/neurofmax_best.pt

  # Three-seed stability check
  for SEED in 42 17 2024; do
    python training/finetune.py --config configs/finetune.yaml --seed $SEED --cv
  done
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import yaml

from data.dataset import PPMIDataset
from models.vit3d import vit3d_base
from models.lora import inject_lora, freeze_backbone, print_trainable_parameters
from models.heads import ClassificationHead, ContrastiveHead
from utils.losses import FineTuningLoss, sqrt_frequency_weights
from utils.reproducibility import seed_everything, BestCheckpointKeeper
from evaluation.metrics import compute_all_metrics, print_metrics_table
from evaluation.calibration import find_optimal_temperature, calibration_report, print_calibration_report
from evaluation.bootstrap import full_bootstrap_report, print_bootstrap_report


CLASS_NAMES   = ["HC", "PD", "Prodromal", "SWEDD"]
CLASS_COUNTS_TRAIN = {"HC": 80, "PD": 96, "Prodromal": 56, "SWEDD": 42}


# ──────────────────────────────────────────────────────────────────────────────
# Model builder
# ──────────────────────────────────────────────────────────────────────────────

def build_model(cfg: dict, pretrained_path: Path, device: torch.device):
    """Build ViT-3D + LoRA + classification head + contrastive head."""
    lora_cfg  = cfg["model"]["lora"]
    cls_cfg   = cfg["model"]["classification_head"]
    con_cfg   = cfg["model"]["contrastive_head"]

    backbone = vit3d_base(dropout=0.1)

    # Load pretrained backbone weights (Stage 1 checkpoint)
    if pretrained_path.exists():
        ckpt = torch.load(pretrained_path, map_location="cpu")
        missing, unexpected = backbone.load_state_dict(
            ckpt.get("model_state_dict", ckpt), strict=False
        )
        print(f"  [pretrain] Loaded {pretrained_path.name}  "
              f"missing={len(missing)} unexpected={len(unexpected)}")
    else:
        print(f"  [pretrain] WARNING: checkpoint not found at {pretrained_path}")

    # Inject LoRA adapters
    inject_lora(
        backbone,
        target_modules=lora_cfg["target_modules"],
        rank=lora_cfg["rank"],
        alpha=lora_cfg["alpha"],
    )

    # Freeze backbone, keep only LoRA adapters + heads trainable
    freeze_backbone(backbone)

    cls_head = ClassificationHead(
        input_dim=cls_cfg["input_dim"],
        num_classes=cls_cfg["num_classes"],
    )
    con_head = ContrastiveHead(
        input_dim=con_cfg["hidden_dim"],
        output_dim=con_cfg["output_dim"],
        num_layers=con_cfg["num_layers"],
    )

    model = NeuroFMAXFinetuner(backbone, cls_head, con_head)
    model = model.to(device)

    print_trainable_parameters(model)
    return model


class NeuroFMAXFinetuner(nn.Module):
    def __init__(self, backbone, cls_head, con_head):
        super().__init__()
        self.backbone = backbone
        self.cls_head = cls_head
        self.con_head = con_head

    def forward(self, token_embeds, modality_ids, visible_mask=None):
        hidden = self.backbone(token_embeds, modality_ids, visible_mask)
        cls_token = hidden[:, 0, :]              # (B, d) [CLS]
        logits    = self.cls_head(cls_token)     # (B, K)
        features  = self.con_head(cls_token)     # (B, 128) ℓ₂-normed
        return logits, features, cls_token


# ──────────────────────────────────────────────────────────────────────────────
# Training loop (single split)
# ──────────────────────────────────────────────────────────────────────────────

def train_one_epoch(
    model, loader, optimizer, loss_fn, device, scheduler=None
) -> dict[str, float]:
    model.train()
    total_loss = total_ce = total_scl = 0.0
    n_correct = n_total = 0

    for batch in loader:
        tokens, mod_ids, labels = (b.to(device) for b in batch)

        optimizer.zero_grad()
        logits, features, _ = model(tokens, mod_ids)
        losses = loss_fn(logits, features, labels)
        losses["loss"].backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        if scheduler is not None:
            scheduler.step()

        B = labels.size(0)
        total_loss += losses["loss"].item() * B
        total_ce   += losses["loss_ce"].item()  * B
        total_scl  += losses["loss_scl"].item() * B
        n_correct  += (logits.argmax(1) == labels).sum().item()
        n_total    += B

    return {
        "loss":     total_loss / n_total,
        "loss_ce":  total_ce  / n_total,
        "loss_scl": total_scl / n_total,
        "accuracy": n_correct  / n_total,
    }


@torch.no_grad()
def evaluate(model, loader, loss_fn, device) -> dict:
    model.eval()
    total_loss = total_ce = 0.0
    all_labels, all_preds, all_probs, all_logits = [], [], [], []

    for batch in loader:
        tokens, mod_ids, labels = (b.to(device) for b in batch)
        logits, features, _ = model(tokens, mod_ids)
        losses = loss_fn(logits, features, labels)

        B = labels.size(0)
        total_loss += losses["loss"].item() * B
        total_ce   += losses["loss_ce"].item()  * B

        probs = torch.softmax(logits, dim=1)
        all_labels.append(labels.cpu().numpy())
        all_preds.append(logits.argmax(1).cpu().numpy())
        all_probs.append(probs.cpu().numpy())
        all_logits.append(logits.cpu().numpy())

    y_true  = np.concatenate(all_labels)
    y_pred  = np.concatenate(all_preds)
    y_prob  = np.concatenate(all_probs)
    logits_np = np.concatenate(all_logits)
    N       = len(y_true)

    report = compute_all_metrics(y_true, y_pred, y_prob)
    report["loss"]    = total_loss / N
    report["loss_ce"] = total_ce   / N
    report["logits"]  = logits_np
    return report


# ──────────────────────────────────────────────────────────────────────────────
# Main training function
# ──────────────────────────────────────────────────────────────────────────────

def run_finetune(cfg: dict, args) -> dict:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    seed_everything(args.seed)

    # Data loaders
    split_file = Path(cfg["data"]["split_dir"]) / f"ppmi_splits_seed{args.seed}.json"
    train_ds = PPMIDataset(
        cfg["data"]["cohort"], split_file, "train",
        data_dir=args.data_dir, modalities=["t1", "flair", "nm_mri"]
    )
    val_ds = PPMIDataset(
        cfg["data"]["cohort"], split_file, "val",
        data_dir=args.data_dir, modalities=["t1", "flair", "nm_mri"]
    )
    test_ds = PPMIDataset(
        cfg["data"]["cohort"], split_file, "test",
        data_dir=args.data_dir, modalities=["t1", "flair", "nm_mri"]
    )
    train_loader = DataLoader(train_ds, batch_size=cfg["training"]["batch_size"],
                              shuffle=True,  num_workers=4, pin_memory=True)
    val_loader   = DataLoader(val_ds,   batch_size=16,
                              shuffle=False, num_workers=4, pin_memory=True)
    test_loader  = DataLoader(test_ds,  batch_size=16,
                              shuffle=False, num_workers=4, pin_memory=True)

    # Model
    pretrained_path = Path(cfg["model"]["pretrained_checkpoint"])
    model = build_model(cfg, pretrained_path, device)

    # Loss
    class_weights = sqrt_frequency_weights(
        CLASS_COUNTS_TRAIN, CLASS_NAMES
    ).to(device)
    loss_fn = FineTuningLoss(
        lambda_scl=cfg["loss"]["lambda_scl"],
        class_weights=class_weights,
        temperature_scl=cfg["loss"]["contrastive_temperature"],
    )

    # Optimizer + scheduler (LoRA params + heads only)
    trainable_params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(
        trainable_params,
        lr=cfg["optimizer"]["peak_lr"],
        weight_decay=cfg["optimizer"]["weight_decay"],
    )
    total_steps = cfg["training"]["total_epochs"] * len(train_loader)
    warmup_steps = cfg["scheduler"]["warmup_epochs"] * len(train_loader)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=total_steps - warmup_steps
    )

    # Checkpoint keeper
    ckpt_dir = Path(cfg["output"]["checkpoint_dir"]) / f"seed{args.seed}"
    keeper = BestCheckpointKeeper(ckpt_dir, model_name=f"neurofmax_seed{args.seed}")

    # Early stopping
    patience = cfg["training"]["early_stopping"]["patience"]
    best_bal_acc = -1.0
    no_improve = 0

    print(f"\n{'='*60}")
    print(f"  Fine-tuning  seed={args.seed}  device={device}")
    print(f"{'='*60}\n")

    # ── Training loop ──
    for epoch in range(1, cfg["training"]["total_epochs"] + 1):
        t0 = time.time()
        train_metrics = train_one_epoch(model, train_loader, optimizer, loss_fn, device)
        val_metrics   = evaluate(model, val_loader, loss_fn, device)

        elapsed = time.time() - t0
        print(
            f"  Epoch {epoch:3d}/{cfg['training']['total_epochs']}  "
            f"train_loss={train_metrics['loss']:.4f}  "
            f"train_acc={train_metrics['accuracy']*100:.1f}%  "
            f"val_loss={val_metrics['loss']:.4f}  "
            f"val_bal_acc={val_metrics['balanced_accuracy']*100:.1f}%  "
            f"[{elapsed:.1f}s]"
        )

        keeper.save(epoch, model, optimizer,
                    val_metrics["loss"], val_metrics["balanced_accuracy"])

        # Early stopping on val balanced accuracy
        if val_metrics["balanced_accuracy"] > best_bal_acc:
            best_bal_acc = val_metrics["balanced_accuracy"]
            no_improve = 0
        else:
            no_improve += 1
        if no_improve >= patience:
            print(f"  Early stop at epoch {epoch} (patience={patience})")
            break

    # ── Temperature calibration on val ──
    keeper.load_best(model, str(device))
    val_eval = evaluate(model, val_loader, loss_fn, device)
    T_star = find_optimal_temperature(val_eval["logits"], val_eval["y_true"] if "y_true" in val_eval else np.array([]))
    print(f"\n  T* = {T_star:.4f}  (fitted on val split)")

    # ── Final evaluation on held-out test set (run ONCE) ──
    print("\n  ── Held-out test set evaluation ──")
    test_eval = evaluate(model, test_loader, loss_fn, device)
    print_metrics_table(test_eval)

    cal_report = calibration_report(test_eval.get("y_true_arr", np.array([])),
                                    test_eval["logits"], T_star)
    print_calibration_report(cal_report)

    # Bootstrap CIs
    # (requires storing y_true_arr separately; see PPMIDataset.__getitem__)

    keeper.save_log()

    return {
        "seed":            args.seed,
        "T_star":          T_star,
        "test_accuracy":   test_eval["accuracy"],
        "test_macro_f1":   test_eval.get("macro_f1", None),
        "calibration":     cal_report,
    }


# ──────────────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="NeuroFM-AX Stage 2 fine-tuning")
    parser.add_argument("--config",     required=True, type=Path)
    parser.add_argument("--seed",       type=int, default=42,
                        help="Random seed (42 = canonical Table 7 seed)")
    parser.add_argument("--data_dir",   type=Path, default=Path("data/preprocessed/ppmi"))
    parser.add_argument("--cv",         action="store_true",
                        help="Run 10-fold cross-validation (hyperparameter selection)")
    parser.add_argument("--eval_only",  action="store_true",
                        help="Skip training; evaluate checkpoint on test set once")
    parser.add_argument("--checkpoint", type=Path, default=None,
                        help="Checkpoint path for --eval_only")
    args = parser.parse_args()

    cfg = yaml.safe_load(args.config.read_text())

    if args.eval_only:
        assert args.checkpoint is not None, "--checkpoint required for --eval_only"
        print(f"  Eval-only mode  checkpoint={args.checkpoint}")
        # Load and evaluate (wiring omitted for brevity; see run_finetune)
    else:
        result = run_finetune(cfg, args)
        out_path = Path(cfg["output"]["log_dir"]) / f"result_seed{args.seed}.json"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(result, indent=2, default=str))
        print(f"\n  Results saved → {out_path}")


if __name__ == "__main__":
    main()
