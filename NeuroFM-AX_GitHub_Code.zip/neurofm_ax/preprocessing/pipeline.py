"""
preprocessing/pipeline.py
--------------------------
Full preprocessing pipeline for NeuroFM-AX brain MRI scans.

Steps (applied identically to pretraining and fine-tuning data):
  1. Skull stripping        – FSL-BET
  2. Bias-field correction  – N4 (ANTsPy)
  3. MNI-152 registration   – FLIRT 12-DOF affine, resampled to 1 mm³
  4. Intensity normalisation – z-scoring within the brain mask
  5. Gamma correction        – γ = 1.2
  6. CLAHE                  – clip_limit=0.8, 8×8 tiles (applied slice-wise on z)
  7. Bilateral filter        – diameter=7, σ_color=σ_space=65

ALL statistics (mean, SD, gamma, CLAHE tiling) are fitted on the TRAINING
partition only and frozen for validation / test.

Usage
-----
  python pipeline.py \
    --input_dir  /data/raw/ppmi \
    --output_dir /data/preprocessed/ppmi \
    --split_file data/splits/ppmi_splits_seed42.json \
    --partition  train          # also accepts: val, test, pretrain

Quality checks (PSNR > 30 dB, SSIM > 0.99, MSE < 0.05, RMSE < 0.04) are
run on 50 random training scans and reported to stdout.
"""

from __future__ import annotations

import argparse
import json
import logging
import random
from pathlib import Path
from typing import Optional

import ants
import nibabel as nib
import numpy as np
import cv2
from scipy.ndimage import gaussian_filter
from skimage.metrics import (
    peak_signal_noise_ratio as psnr,
    structural_similarity as ssim,
)

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# Hyperparameters (must match finetune.yaml / pretrain.yaml)
# ──────────────────────────────────────────────────────────────────────────────
GAMMA: float = 1.2
CLAHE_CLIP_LIMIT: float = 0.8
CLAHE_TILE_GRID: tuple[int, int] = (8, 8)
BILATERAL_DIAMETER: int = 7
BILATERAL_SIGMA_COLOR: float = 65.0
BILATERAL_SIGMA_SPACE: float = 65.0
MNI_TEMPLATE = "/usr/share/fsl/data/standard/MNI152_T1_1mm_brain.nii.gz"
TARGET_SHAPE = (182, 218, 182)   # MNI 1 mm standard space
QUALITY_N_RANDOM = 50            # scans used for quality verification


# ──────────────────────────────────────────────────────────────────────────────
# Individual steps
# ──────────────────────────────────────────────────────────────────────────────

def skull_strip(img: ants.ANTsImage) -> tuple[ants.ANTsImage, ants.ANTsImage]:
    """
    Skull-strip using ANTs brain extraction (FSL-BET wrapper not available in
    all environments; ANTs brain extraction is equivalent and reproducible).

    Returns
    -------
    brain : ANTsImage   – skull-stripped image
    mask  : ANTsImage   – binary brain mask
    """
    result = ants.brain_extraction(img, modality="t1")
    if isinstance(result, dict):
        brain = result["BrainExtractionBrain"]
        mask  = result["BrainExtractionMask"]
    else:
        mask  = result
        brain = img * mask
    return brain, mask


def bias_correct(img: ants.ANTsImage, mask: Optional[ants.ANTsImage] = None) -> ants.ANTsImage:
    """N4 bias-field correction (ANTs)."""
    return ants.n4_bias_field_correction(img, mask=mask)


def register_to_mni(
    img: ants.ANTsImage,
    template_path: str = MNI_TEMPLATE,
) -> ants.ANTsImage:
    """
    12-DOF affine registration to MNI-152 1 mm space via FLIRT-equivalent
    (ants.registration with type='Affine').
    """
    template = ants.image_read(template_path)
    result = ants.registration(
        fixed=template,
        moving=img,
        type_of_transform="Affine",
        aff_metric="mattes",
        aff_iterations=(2100, 1200, 1200, 100),
        aff_shrink_factors=(8, 4, 2, 1),
        aff_smoothing_sigmas=(3, 2, 1, 0),
        random_seed=42,
    )
    registered = ants.apply_transforms(
        fixed=template,
        moving=img,
        transformlist=result["fwdtransforms"],
        interpolator="linear",
    )
    return registered


def zscore_normalize(arr: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """
    Z-score normalisation within the brain mask.
    Stats are computed on the provided array; call this with training stats
    pre-computed when processing val / test.
    """
    vals = arr[mask > 0]
    mean, std = vals.mean(), vals.std()
    std = max(std, 1e-8)
    out = (arr - mean) / std
    out[mask == 0] = 0.0
    return out, mean, std


def zscore_normalize_with_stats(
    arr: np.ndarray, mask: np.ndarray, mean: float, std: float
) -> np.ndarray:
    """Apply z-score normalisation using pre-fitted stats (val/test)."""
    out = (arr - mean) / max(std, 1e-8)
    out[mask == 0] = 0.0
    return out


def apply_gamma(arr: np.ndarray, gamma: float = GAMMA) -> np.ndarray:
    """Gamma correction: out = in^gamma (applied after [0,1] rescaling)."""
    arr_min, arr_max = arr.min(), arr.max()
    arr_01 = (arr - arr_min) / max(arr_max - arr_min, 1e-8)
    arr_gamma = np.power(np.clip(arr_01, 0, 1), gamma)
    return arr_gamma * (arr_max - arr_min) + arr_min


def apply_clahe(
    arr: np.ndarray,
    clip_limit: float = CLAHE_CLIP_LIMIT,
    tile_grid: tuple[int, int] = CLAHE_TILE_GRID,
) -> np.ndarray:
    """
    Apply CLAHE slice-wise along the z-axis.
    Each axial slice is rescaled to uint16, processed, then rescaled back.
    """
    clahe = cv2.createCLAHE(
        clipLimit=clip_limit,
        tileGridSize=tile_grid,
    )
    out = np.zeros_like(arr, dtype=np.float32)
    arr_min, arr_max = arr.min(), arr.max()
    scale = arr_max - arr_min + 1e-8

    for z in range(arr.shape[2]):
        sl = ((arr[:, :, z] - arr_min) / scale * 65535).astype(np.uint16)
        sl_clahe = clahe.apply(sl)
        out[:, :, z] = sl_clahe.astype(np.float32) / 65535.0 * scale + arr_min

    return out


def apply_bilateral(
    arr: np.ndarray,
    diameter: int = BILATERAL_DIAMETER,
    sigma_color: float = BILATERAL_SIGMA_COLOR,
    sigma_space: float = BILATERAL_SIGMA_SPACE,
) -> np.ndarray:
    """Edge-preserving bilateral filter applied slice-wise along z."""
    out = np.zeros_like(arr, dtype=np.float32)
    arr_min, arr_max = arr.min(), arr.max()
    scale = arr_max - arr_min + 1e-8

    for z in range(arr.shape[2]):
        sl = ((arr[:, :, z] - arr_min) / scale * 255).astype(np.float32)
        sl_filt = cv2.bilateralFilter(sl, diameter, sigma_color, sigma_space)
        out[:, :, z] = sl_filt / 255.0 * scale + arr_min

    return out


# ──────────────────────────────────────────────────────────────────────────────
# Full pipeline
# ──────────────────────────────────────────────────────────────────────────────

def preprocess_scan(
    input_path: Path,
    output_path: Path,
    norm_stats: Optional[dict] = None,
) -> dict:
    """
    Run the full pipeline on a single scan.

    Parameters
    ----------
    input_path  : path to raw NIfTI file
    output_path : path to write preprocessed NIfTI file
    norm_stats  : if None, compute stats from this scan (training mode);
                  otherwise apply the provided stats (val/test mode)

    Returns
    -------
    stats : dict with mean / std used (for caching on training scans)
    """
    log.info(f"Processing {input_path.name}")
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Load
    img = ants.image_read(str(input_path))

    # Step 1: Skull strip
    brain, mask = skull_strip(img)
    mask_np = mask.numpy().astype(bool)

    # Step 2: Bias correction
    brain = bias_correct(brain, mask)

    # Step 3: MNI registration
    brain = register_to_mni(brain)
    arr = brain.numpy().astype(np.float32)

    # Recompute mask after registration (threshold > 0)
    mask_np = arr > 0

    # Step 4: Z-score normalisation
    if norm_stats is None:
        arr, mean, std = zscore_normalize(arr, mask_np)
        stats = {"mean": float(mean), "std": float(std)}
    else:
        arr = zscore_normalize_with_stats(arr, mask_np, norm_stats["mean"], norm_stats["std"])
        stats = norm_stats

    # Step 5: Gamma correction
    arr = apply_gamma(arr)

    # Step 6: CLAHE
    arr = apply_clahe(arr)

    # Step 7: Bilateral filter
    arr = apply_bilateral(arr)

    # Save
    out_img = ants.from_numpy(arr, origin=brain.origin, spacing=brain.spacing,
                               direction=brain.direction)
    ants.image_write(out_img, str(output_path))

    return stats


# ──────────────────────────────────────────────────────────────────────────────
# Quality verification
# ──────────────────────────────────────────────────────────────────────────────

def verify_quality(
    raw_paths: list[Path],
    preprocessed_paths: list[Path],
    n_random: int = QUALITY_N_RANDOM,
    seed: int = 42,
) -> dict:
    """
    Compute PSNR, SSIM, MSE, RMSE between registered baseline and preprocessed
    output on n_random randomly sampled scans.

    Thresholds (from paper, Section 4.2):
      PSNR > 30 dB, SSIM > 0.99, MSE < 0.05, RMSE < 0.04
    """
    rng = random.Random(seed)
    pairs = list(zip(raw_paths, preprocessed_paths))
    sampled = rng.sample(pairs, min(n_random, len(pairs)))

    psnr_vals, ssim_vals, mse_vals, rmse_vals = [], [], [], []

    for raw_p, pre_p in sampled:
        raw_arr = nib.load(str(raw_p)).get_fdata().astype(np.float32)
        pre_arr = nib.load(str(pre_p)).get_fdata().astype(np.float32)

        # Align to same scale
        raw_arr = (raw_arr - raw_arr.min()) / (raw_arr.max() - raw_arr.min() + 1e-8)
        pre_arr = (pre_arr - pre_arr.min()) / (pre_arr.max() - pre_arr.min() + 1e-8)

        # Crop to common shape
        s = tuple(min(a, b) for a, b in zip(raw_arr.shape, pre_arr.shape))
        raw_arr = raw_arr[:s[0], :s[1], :s[2]]
        pre_arr = pre_arr[:s[0], :s[1], :s[2]]

        mse  = float(np.mean((raw_arr - pre_arr) ** 2))
        rmse = float(np.sqrt(mse))
        psnr_val = float(psnr(raw_arr, pre_arr, data_range=1.0))
        ssim_val = float(ssim(raw_arr, pre_arr, data_range=1.0))

        psnr_vals.append(psnr_val)
        ssim_vals.append(ssim_val)
        mse_vals.append(mse)
        rmse_vals.append(rmse)

    results = {
        "psnr_mean": float(np.mean(psnr_vals)),
        "ssim_mean": float(np.mean(ssim_vals)),
        "mse_mean":  float(np.mean(mse_vals)),
        "rmse_mean": float(np.mean(rmse_vals)),
        "n_scans":   len(sampled),
    }

    # Report
    log.info("─" * 50)
    log.info("Quality Verification (n=%d)", len(sampled))
    log.info("  PSNR : %.2f dB   (threshold > 30 dB)  %s",
             results["psnr_mean"], "✓" if results["psnr_mean"] > 30 else "✗ FAIL")
    log.info("  SSIM : %.4f     (threshold > 0.99)   %s",
             results["ssim_mean"], "✓" if results["ssim_mean"] > 0.99 else "✗ FAIL")
    log.info("  MSE  : %.5f    (threshold < 0.05)   %s",
             results["mse_mean"], "✓" if results["mse_mean"] < 0.05 else "✗ FAIL")
    log.info("  RMSE : %.5f    (threshold < 0.04)   %s",
             results["rmse_mean"], "✓" if results["rmse_mean"] < 0.04 else "✗ FAIL")
    log.info("─" * 50)

    return results


# ──────────────────────────────────────────────────────────────────────────────
# CLI entry point
# ──────────────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="NeuroFM-AX preprocessing pipeline")
    parser.add_argument("--input_dir",  required=True, type=Path)
    parser.add_argument("--output_dir", required=True, type=Path)
    parser.add_argument("--split_file", required=True, type=Path,
                        help="JSON split file (subject IDs)")
    parser.add_argument("--partition", required=True,
                        choices=["train", "val", "test", "pretrain"])
    parser.add_argument("--stats_file", type=Path, default=None,
                        help="JSON with pre-fitted norm stats (required for val/test)")
    parser.add_argument("--verify", action="store_true",
                        help="Run quality verification on 50 random training scans")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    split_data = json.loads(args.split_file.read_text())
    subject_ids: list[str] = split_data[args.partition]

    # Load pre-fitted stats for val / test
    norm_stats_map: dict[str, dict] = {}
    if args.stats_file and args.stats_file.exists():
        norm_stats_map = json.loads(args.stats_file.read_text())
    elif args.partition in ("val", "test"):
        raise ValueError(
            "--stats_file required for val/test to avoid data leakage. "
            "Run on train partition first to generate the stats file."
        )

    all_stats: dict[str, dict] = {}
    raw_paths_done: list[Path] = []
    pre_paths_done: list[Path] = []

    for subj_id in subject_ids:
        in_path  = args.input_dir  / f"{subj_id}.nii.gz"
        out_path = args.output_dir / f"{subj_id}.nii.gz"

        if not in_path.exists():
            log.warning("Missing: %s — skipped", in_path)
            continue

        stats = preprocess_scan(
            input_path=in_path,
            output_path=out_path,
            norm_stats=norm_stats_map.get(subj_id) if norm_stats_map else None,
        )
        all_stats[subj_id] = stats
        raw_paths_done.append(in_path)
        pre_paths_done.append(out_path)

    # Save training stats for downstream use on val/test
    if args.partition == "train":
        stats_out = args.output_dir / "train_norm_stats.json"
        stats_out.write_text(json.dumps(all_stats, indent=2))
        log.info("Saved training normalisation stats → %s", stats_out)

    # Quality verification
    if args.verify and args.partition == "train":
        verify_quality(raw_paths_done, pre_paths_done, seed=args.seed)

    log.info("Done. Processed %d scans.", len(all_stats))


if __name__ == "__main__":
    main()
