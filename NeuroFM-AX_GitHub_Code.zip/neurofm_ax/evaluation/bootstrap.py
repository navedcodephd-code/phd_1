"""
evaluation/bootstrap.py & statistical_tests.py (combined)
-----------------------------------------------------------
Bootstrap 95% confidence intervals and paired bootstrap significance tests
as described in Section 3.4 and Section 4.3 of the paper.

B = 1000 bootstrap samples (resampling with replacement from the test set).

Paper values (Table 4 / Section 5.2):
  Accuracy CI   : [89.33, 98.67]
  Macro-AUC     : 0.992
  ECE (after T*): 0.028

Paired bootstrap test (Section 4.3 / 5.7):
  NeuroFM-AX vs SwinClassifier  p < 0.01  (B=1000 fold-level resampling)
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Callable

import numpy as np

from evaluation.metrics import confusion_matrix, accuracy, per_class_metrics, macro_metrics
from evaluation.calibration import brier_score, ece_mce, apply_temperature


# ──────────────────────────────────────────────────────────────────────────────
# Generic bootstrap engine
# ──────────────────────────────────────────────────────────────────────────────

def bootstrap_metric(
    fn: Callable[[np.ndarray, np.ndarray], float],
    y_true: np.ndarray,
    y_pred: np.ndarray,
    n_bootstrap: int = 1000,
    confidence: float = 0.95,
    seed: int = 42,
) -> dict[str, float]:
    """
    Compute a scalar metric with bootstrap confidence interval.

    Parameters
    ----------
    fn          : function(y_true_boot, y_pred_boot) → float
    y_true      : ground-truth labels
    y_pred      : model predictions or probabilities
    n_bootstrap : number of bootstrap resamples (1000)
    confidence  : CI level (0.95)
    seed        : random seed for reproducibility

    Returns
    -------
    { "point": float, "ci_lo": float, "ci_hi": float, "se": float }
    """
    rng = np.random.default_rng(seed)
    N   = len(y_true)
    bootstrap_vals = []

    for _ in range(n_bootstrap):
        idx = rng.integers(0, N, size=N)    # resample with replacement
        boot_val = fn(y_true[idx], y_pred[idx])
        bootstrap_vals.append(boot_val)

    bootstrap_vals = np.array(bootstrap_vals)
    alpha = 1.0 - confidence
    ci_lo = float(np.percentile(bootstrap_vals, 100 * alpha / 2))
    ci_hi = float(np.percentile(bootstrap_vals, 100 * (1 - alpha / 2)))

    return {
        "point": float(fn(y_true, y_pred)),
        "ci_lo": ci_lo,
        "ci_hi": ci_hi,
        "se":    float(bootstrap_vals.std()),
    }


# ──────────────────────────────────────────────────────────────────────────────
# Full bootstrap report (Table 4 style)
# ──────────────────────────────────────────────────────────────────────────────

def full_bootstrap_report(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: np.ndarray,
    logits: np.ndarray,
    T_star: float,
    n_bootstrap: int = 1000,
    seed: int = 42,
) -> dict:
    """
    Compute all bootstrap CIs reported in the paper:
      accuracy, balanced accuracy, per-class precision / recall / F1,
      macro-F1, macro-AUC, ECE (after T*), MCE, Brier.
    """
    from sklearn.metrics import roc_auc_score

    rng  = np.random.default_rng(seed)
    N    = len(y_true)
    K    = y_prob.shape[1]
    CLASSES = ["HC", "PD", "Prodromal", "SWEDD"]

    # Storage
    acc_vals  = []
    bal_vals  = []
    prec_vals = {c: [] for c in CLASSES}
    rec_vals  = {c: [] for c in CLASSES}
    f1_vals   = {c: [] for c in CLASSES}
    auc_vals  = {c: [] for c in CLASSES}
    mauc_vals = []
    ece_vals  = []
    mce_vals  = []
    brier_vals= []

    for _ in range(n_bootstrap):
        idx = rng.integers(0, N, size=N)

        yt  = y_true[idx]
        yp  = y_pred[idx]
        ypr = y_prob[idx]
        lg  = logits[idx]

        # Apply temperature
        cal_prob = apply_temperature(lg, T_star)

        cm  = confusion_matrix(yt, yp, K)
        pc  = per_class_metrics(cm)
        acc_vals.append(accuracy(cm))
        bal_vals.append(np.mean([v["recall"] for v in pc.values()]))

        for k, cls in enumerate(CLASSES):
            prec_vals[cls].append(pc[cls]["precision"])
            rec_vals[cls].append(pc[cls]["recall"])
            f1_vals[cls].append(pc[cls]["f1"])
            bin_true = (yt == k).astype(int)
            # Guard: both classes must appear
            if bin_true.sum() > 0 and bin_true.sum() < len(bin_true):
                auc_vals[cls].append(roc_auc_score(bin_true, ypr[:, k]))

        mauc_vals.append(np.mean([
            roc_auc_score((yt == k).astype(int), ypr[:, k])
            for k in range(K)
            if 0 < (yt == k).sum() < len(yt)
        ]))

        em    = ece_mce(yt, cal_prob)
        ece_vals.append(em["ece"])
        mce_vals.append(em["mce"])
        brier_vals.append(brier_score(yt, cal_prob))

    alpha = 0.05

    def ci(vals):
        a = np.array(vals)
        return {
            "mean":  float(a.mean()),
            "ci_lo": float(np.percentile(a, 2.5)),
            "ci_hi": float(np.percentile(a, 97.5)),
            "se":    float(a.std()),
        }

    report = {
        "n_bootstrap": n_bootstrap,
        "accuracy":           ci(acc_vals),
        "balanced_accuracy":  ci(bal_vals),
        "macro_auc":          ci(mauc_vals),
        "ece_after_cal":      ci(ece_vals),
        "mce_after_cal":      ci(mce_vals),
        "brier_after_cal":    ci(brier_vals),
        "per_class": {
            cls: {
                "precision": ci(prec_vals[cls]),
                "recall":    ci(rec_vals[cls]),
                "f1":        ci(f1_vals[cls]),
                "auc":       ci(auc_vals[cls]) if auc_vals[cls] else None,
            }
            for cls in CLASSES
        },
    }
    return report


def print_bootstrap_report(report: dict) -> None:
    CLASSES = ["HC", "PD", "Prodromal", "SWEDD"]
    print("\n" + "=" * 72)
    print(f"  Bootstrap CIs  (B = {report['n_bootstrap']})")
    print("=" * 72)

    def fmt(d):
        if d is None:
            return "     N/A"
        return f"{d['mean']*100:6.2f}% [{d['ci_lo']*100:.2f},{d['ci_hi']*100:.2f}]"

    acc = report["accuracy"]
    print(f"  Accuracy    : {acc['mean']*100:.2f}%  [{acc['ci_lo']*100:.2f}, {acc['ci_hi']*100:.2f}]")

    print(f"\n  {'Class':>12}  {'Precision':>24}  {'Recall':>24}  {'F1':>24}")
    print("-" * 72)
    for cls in CLASSES:
        pc = report["per_class"][cls]
        print(
            f"  {cls:>12}  {fmt(pc['precision'])}  "
            f"{fmt(pc['recall'])}  {fmt(pc['f1'])}"
        )

    mauc = report["macro_auc"]
    print(f"\n  Macro-AUC   : {mauc['mean']:.4f}  [{mauc['ci_lo']:.4f}, {mauc['ci_hi']:.4f}]")
    ece  = report["ece_after_cal"]
    print(f"  ECE (cal.)  : {ece['mean']:.4f}  [{ece['ci_lo']:.4f}, {ece['ci_hi']:.4f}]")
    print("=" * 72 + "\n")


# ──────────────────────────────────────────────────────────────────────────────
# Paired bootstrap significance test (Section 4.3 / 5.7)
# ──────────────────────────────────────────────────────────────────────────────

def paired_bootstrap_test(
    model_fold_accs:    np.ndarray,   # (n_folds,) CV accuracies for our model
    baseline_fold_accs: np.ndarray,   # (n_folds,) CV accuracies for baseline
    n_bootstrap: int = 1000,
    seed: int = 42,
) -> dict[str, float]:
    """
    Non-parametric paired bootstrap test on fold-level CV accuracies.

    H₀: mean(model) = mean(baseline)
    H₁: mean(model) > mean(baseline)

    p-value = fraction of bootstrap samples where Δ_boot ≤ 0
    (two-sided: fraction where |Δ_boot| ≥ |Δ_obs|)

    Used in the paper: NeuroFM-AX vs SwinClassifier  →  p < 0.01

    Parameters
    ----------
    model_fold_accs    : (n_folds,) per-fold accuracy for NeuroFM-AX
    baseline_fold_accs : (n_folds,) per-fold accuracy for the baseline

    Returns
    -------
    { "delta_obs": float, "p_value_one_sided": float, "p_value_two_sided": float }
    """
    assert len(model_fold_accs) == len(baseline_fold_accs)
    rng = np.random.default_rng(seed)
    n   = len(model_fold_accs)

    diff = model_fold_accs - baseline_fold_accs
    delta_obs = float(diff.mean())

    # Centre the differences under H₀
    diff_centred = diff - delta_obs

    # Bootstrap
    bootstrap_deltas = np.array([
        rng.choice(diff_centred, size=n, replace=True).mean()
        for _ in range(n_bootstrap)
    ])

    p_one_sided = float((bootstrap_deltas <= 0).mean())
    p_two_sided = float((np.abs(bootstrap_deltas) >= abs(delta_obs)).mean())

    return {
        "delta_obs":           delta_obs,
        "p_value_one_sided":   p_one_sided,
        "p_value_two_sided":   p_two_sided,
        "n_bootstrap":         n_bootstrap,
        "significant_at_001":  p_one_sided < 0.01,
    }


def run_all_significance_tests(
    neurofmax_fold_accs: np.ndarray,
    baseline_accs_dict: dict[str, np.ndarray],
    n_bootstrap: int = 1000,
    seed: int = 42,
) -> None:
    """Print paired bootstrap test results against all baselines (Table 7)."""
    print("\n" + "=" * 60)
    print("  Paired Bootstrap Tests vs. NeuroFM-AX (10-fold CV)")
    print("=" * 60)
    print(f"  {'Baseline':>20}  {'Δ (pp)':>8}  {'p (one-sided)':>14}  sig@0.01")
    print("-" * 60)

    for name, accs in baseline_accs_dict.items():
        result = paired_bootstrap_test(
            neurofmax_fold_accs, accs, n_bootstrap=n_bootstrap, seed=seed
        )
        sig = "✓" if result["significant_at_001"] else "✗"
        print(
            f"  {name:>20}  "
            f"{result['delta_obs']*100:>+7.2f}pp  "
            f"{result['p_value_one_sided']:>14.4f}  {sig}"
        )
    print("=" * 60 + "\n")


# ──────────────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_preds",    required=True, type=Path,
                        help=".npy file with shape (n_folds, n_samples) CV preds")
    parser.add_argument("--baseline_preds", required=True, type=Path,
                        help=".npy file for baseline CV preds")
    parser.add_argument("--n_bootstrap", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    model_accs    = np.load(args.model_preds)
    baseline_accs = np.load(args.baseline_preds)

    result = paired_bootstrap_test(
        model_accs, baseline_accs,
        n_bootstrap=args.n_bootstrap,
        seed=args.seed,
    )
    print(f"\nΔ_obs    = {result['delta_obs']*100:+.4f} pp")
    print(f"p (one-sided) = {result['p_value_one_sided']:.4f}")
    print(f"p (two-sided) = {result['p_value_two_sided']:.4f}")
    print(f"Significant at 0.01? {result['significant_at_001']}")
