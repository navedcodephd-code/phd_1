"""
evaluation/calibration.py
--------------------------
Temperature scaling calibration + ECE / MCE / Brier score.

T* is fitted on the VALIDATION split only.
The test set is never used for this fit (Section 3.4 / 4.3 of the paper).

Optimal T*=0.91 reported in the paper (Section 5.3).
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.optimize import minimize_scalar


# ──────────────────────────────────────────────────────────────────────────────
# Temperature scaling
# ──────────────────────────────────────────────────────────────────────────────

def find_optimal_temperature(
    logits_val: np.ndarray,    # (N_val, K) raw logits from the model
    labels_val: np.ndarray,    # (N_val,)   integer true labels
    t_min: float = 0.1,
    t_max: float = 10.0,
) -> float:
    """
    Find T* = argmin_T  NLL(labels_val | softmax(logits_val / T)).
    Uses scalar Brent optimisation (no gradient required).

    Returns
    -------
    T_star : float   (0.91 for the paper's model)
    """
    logits = torch.from_numpy(logits_val).float()
    labels = torch.from_numpy(labels_val).long()
    nll_fn = nn.CrossEntropyLoss()

    def nll(T: float) -> float:
        scaled = logits / max(T, 1e-8)
        return float(nll_fn(scaled, labels).item())

    result = minimize_scalar(nll, bounds=(t_min, t_max), method="bounded")
    T_star = float(result.x)
    return T_star


def apply_temperature(logits: np.ndarray, T: float) -> np.ndarray:
    """Return calibrated softmax probabilities: softmax(logits / T)."""
    scaled = logits / max(T, 1e-8)
    # Numerically stable softmax
    shifted = scaled - scaled.max(axis=1, keepdims=True)
    exp_s   = np.exp(shifted)
    return exp_s / exp_s.sum(axis=1, keepdims=True)


# ──────────────────────────────────────────────────────────────────────────────
# Reliability metrics (ECE, MCE, Brier)
# ──────────────────────────────────────────────────────────────────────────────

def ece_mce(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    n_bins: int = 10,
) -> dict[str, float]:
    """
    Expected Calibration Error (ECE) and Maximum Calibration Error (MCE).

    Eq. 10 from the paper:
      ECE = Σ_m  |B_m|/N  ·  |acc(B_m) − conf(B_m)|
      MCE = max_m            |acc(B_m) − conf(B_m)|

    Bins are equal-width on [0, 1] based on the max-class confidence.

    Parameters
    ----------
    y_true : (N,)    integer labels
    y_prob : (N, K)  calibrated softmax probabilities
    n_bins : number of equal-width confidence bins (10)
    """
    N = len(y_true)
    y_pred  = y_prob.argmax(axis=1)
    conf    = y_prob.max(axis=1)     # max-class confidence
    correct = (y_pred == y_true).astype(float)

    bin_edges = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    mce = 0.0
    bin_stats = []

    for m in range(n_bins):
        lo, hi = bin_edges[m], bin_edges[m + 1]
        mask = (conf > lo) & (conf <= hi)
        if mask.sum() == 0:
            bin_stats.append(None)
            continue

        acc_m  = correct[mask].mean()
        conf_m = conf[mask].mean()
        gap    = abs(acc_m - conf_m)
        weight = mask.sum() / N

        ece += weight * gap
        mce  = max(mce, gap)
        bin_stats.append({"acc": acc_m, "conf": conf_m, "n": int(mask.sum())})

    return {"ece": float(ece), "mce": float(mce), "bin_stats": bin_stats}


def brier_score(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    """
    Multi-class Brier score (Eq. 11):
      Brier = (1/N) Σ_i Σ_k (p_k(x_i) − 1[y_i = k])²
    """
    N, K = y_prob.shape
    one_hot = np.zeros_like(y_prob)
    one_hot[np.arange(N), y_true.astype(int)] = 1.0
    return float(np.mean(np.sum((y_prob - one_hot) ** 2, axis=1)))


def calibration_report(
    y_true: np.ndarray,
    logits_uncal: np.ndarray,
    T_star: float,
    n_bins: int = 10,
) -> dict:
    """
    Full calibration report before and after temperature scaling.

    Returns
    -------
    dict with keys:
      before / after  →  { ece, mce, brier, T }
    """
    # Before calibration (T = 1.0)
    prob_before = apply_temperature(logits_uncal, T=1.0)
    em_before   = ece_mce(y_true, prob_before, n_bins)
    br_before   = brier_score(y_true, prob_before)

    # After calibration
    prob_after  = apply_temperature(logits_uncal, T=T_star)
    em_after    = ece_mce(y_true, prob_after, n_bins)
    br_after    = brier_score(y_true, prob_after)

    report = {
        "T_star": T_star,
        "before": {
            "ece":   em_before["ece"],
            "mce":   em_before["mce"],
            "brier": br_before,
            "T":     1.0,
        },
        "after": {
            "ece":   em_after["ece"],
            "mce":   em_after["mce"],
            "brier": br_after,
            "T":     T_star,
        },
        "bin_stats_before": em_before["bin_stats"],
        "bin_stats_after":  em_after["bin_stats"],
    }
    return report


def print_calibration_report(report: dict) -> None:
    print("\n" + "=" * 50)
    print(f"  Temperature scaling  T* = {report['T_star']:.4f}")
    print("=" * 50)
    for stage in ("before", "after"):
        d = report[stage]
        print(
            f"  {stage.upper():>6}  "
            f"ECE={d['ece']:.4f}  "
            f"MCE={d['mce']:.4f}  "
            f"Brier={d['brier']:.4f}"
        )
    print("=" * 50 + "\n")
