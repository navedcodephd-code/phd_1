"""
evaluation/metrics.py
----------------------
All per-class and macro metrics for NeuroFM-AX, derived exclusively
from the integer confusion matrix on the held-out test set.

Classes: HC=0, PD=1, Prodromal=2, SWEDD=3

All values in this module are traceable to Table 4 and Figure 6a.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import numpy as np
import torch


CLASSES = ["HC", "PD", "Prodromal", "SWEDD"]
CLASS_TO_IDX = {c: i for i, c in enumerate(CLASSES)}


# ──────────────────────────────────────────────────────────────────────────────
# Integer confusion matrix
# ──────────────────────────────────────────────────────────────────────────────

def confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    num_classes: int = 4,
) -> np.ndarray:
    """
    Build an integer confusion matrix of shape (num_classes, num_classes).
    Rows = true labels, columns = predicted labels.
    """
    cm = np.zeros((num_classes, num_classes), dtype=int)
    for t, p in zip(y_true, y_pred):
        cm[int(t), int(p)] += 1
    return cm


def verify_integer_cm(cm: np.ndarray, n_samples: int) -> None:
    """
    Consistency checks:
      1. All entries are non-negative integers
      2. Row sums match per-class N
      3. Diagonal sum = correct predictions → accuracy = diag_sum / n_samples
    """
    assert cm.dtype in (int, np.int32, np.int64), "CM must be integer dtype"
    assert (cm >= 0).all(), "CM has negative entries"
    assert cm.sum() == n_samples, (
        f"CM total {cm.sum()} ≠ n_samples {n_samples}"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Per-class metrics
# ──────────────────────────────────────────────────────────────────────────────

def per_class_metrics(cm: np.ndarray) -> dict[str, dict[str, float]]:
    """
    Compute precision, recall, F1 per class from the integer confusion matrix.
    All values are in [0, 1].
    """
    K = cm.shape[0]
    results = {}
    for k in range(K):
        tp = cm[k, k]
        fp = cm[:, k].sum() - tp
        fn = cm[k, :].sum() - tp

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1        = (2 * precision * recall / (precision + recall)
                     if (precision + recall) > 0 else 0.0)

        results[CLASSES[k]] = {
            "precision": float(precision),
            "recall":    float(recall),
            "f1":        float(f1),
            "tp":        int(tp),
            "fp":        int(fp),
            "fn":        int(fn),
        }
    return results


def macro_metrics(per_class: dict[str, dict[str, float]]) -> dict[str, float]:
    """Unweighted macro-average precision, recall, F1."""
    return {
        "macro_precision": float(np.mean([v["precision"] for v in per_class.values()])),
        "macro_recall":    float(np.mean([v["recall"]    for v in per_class.values()])),
        "macro_f1":        float(np.mean([v["f1"]        for v in per_class.values()])),
    }


def accuracy(cm: np.ndarray) -> float:
    """Overall accuracy = sum(diagonal) / sum(all)."""
    return float(cm.diagonal().sum() / cm.sum())


def balanced_accuracy(per_class: dict[str, dict[str, float]]) -> float:
    """Balanced accuracy = macro recall."""
    return float(np.mean([v["recall"] for v in per_class.values()]))


# ──────────────────────────────────────────────────────────────────────────────
# AUC (one-vs-rest, from soft probabilities)
# ──────────────────────────────────────────────────────────────────────────────

def per_class_auc(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    num_classes: int = 4,
) -> dict[str, float]:
    """
    One-vs-rest AUC per class.
    y_prob : (N, K) soft probabilities (after temperature scaling).
    """
    from sklearn.metrics import roc_auc_score

    results = {}
    for k, cls in enumerate(CLASSES[:num_classes]):
        binary_true = (y_true == k).astype(int)
        results[cls] = float(roc_auc_score(binary_true, y_prob[:, k]))
    results["macro_auc"] = float(np.mean(list(results.values())))
    return results


# ──────────────────────────────────────────────────────────────────────────────
# Full metrics report
# ──────────────────────────────────────────────────────────────────────────────

def compute_all_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: Optional[np.ndarray] = None,
) -> dict:
    """
    Compute and return all metrics reported in Table 4.

    Parameters
    ----------
    y_true : (N,) integer class labels
    y_pred : (N,) integer predicted labels
    y_prob : (N, 4) soft probabilities (required for AUC)
    """
    n = len(y_true)
    cm = confusion_matrix(y_true, y_pred)
    verify_integer_cm(cm, n)

    pc  = per_class_metrics(cm)
    mac = macro_metrics(pc)
    acc = accuracy(cm)
    bal = balanced_accuracy(pc)

    report = {
        "n_samples":          n,
        "accuracy":           acc,
        "balanced_accuracy":  bal,
        "confusion_matrix":   cm.tolist(),
        "per_class":          pc,
        **mac,
    }

    if y_prob is not None:
        auc = per_class_auc(y_true, y_prob)
        report["auc"] = auc

    return report


def print_metrics_table(report: dict) -> None:
    """Pretty-print metrics in the style of Table 4."""
    print("\n" + "=" * 65)
    print(f"  N = {report['n_samples']}  |  "
          f"Accuracy: {report['accuracy']*100:.2f}%  |  "
          f"Bal-Acc: {report['balanced_accuracy']*100:.2f}%")
    print("=" * 65)
    hdr = f"{'Class':>12}  {'Prec':>7}  {'Recall':>7}  {'F1':>7}  {'AUC':>7}"
    print(hdr)
    print("-" * 65)
    for cls, vals in report["per_class"].items():
        auc_val = report.get("auc", {}).get(cls, float("nan"))
        print(
            f"  {cls:>10}  "
            f"{vals['precision']*100:>6.2f}%  "
            f"{vals['recall']*100:>6.2f}%  "
            f"{vals['f1']*100:>6.2f}%  "
            f"{auc_val:>7.3f}"
        )
    print("-" * 65)
    print(
        f"  {'Macro':>10}  "
        f"{report['macro_precision']*100:>6.2f}%  "
        f"{report['macro_recall']*100:>6.2f}%  "
        f"{report['macro_f1']*100:>6.2f}%  "
        f"{report.get('auc',{}).get('macro_auc',float('nan')):>7.3f}"
    )
    print("=" * 65 + "\n")


# ──────────────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--split",      required=True, choices=["val", "test"])
    parser.add_argument("--split_file", required=True, type=Path)
    parser.add_argument("--data_dir",   required=True, type=Path)
    parser.add_argument("--output",     type=Path, default=None)
    args = parser.parse_args()

    # NOTE: Full evaluation script wires model loading + dataset here.
    # The standalone helper above is importable from training/finetune.py.
    print("Use training/finetune.py --eval_only for end-to-end evaluation.")
