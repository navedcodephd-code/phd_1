"""
utils/losses.py
---------------
Loss functions for NeuroFM-AX Stage 2 fine-tuning.

  L = L_CE  +  λ · L_SCL      (Eq. 8, λ = 0.5)

  L_SCL : Supervised Contrastive Loss with hard-negative re-weighting
          (Khosla et al., 2020 — Eq. 7 in the paper)
          τ = 0.07

  L_MVM : Masked Volume Modelling reconstruction loss (Eq. 3–5) for Stage 1.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


# ──────────────────────────────────────────────────────────────────────────────
# Supervised Contrastive Loss (SCL) with hard-negative mining
# ──────────────────────────────────────────────────────────────────────────────

class SupervisedContrastiveLoss(nn.Module):
    """
    Supervised contrastive loss (Khosla et al., 2020) extended with
    hard-negative re-weighting.

    For each anchor i:
      • Positives  P(i)  = {j ≠ i : y_j = y_i}
      • Anchors    A(i)  = {1,...,B} \ {i}
      • Hard-negative weight w_{i,a} ∝ exp(v_i^T v_a / τ)
        → negatives closer to the anchor contribute more to the gradient

    Parameters
    ----------
    temperature : τ = 0.07 (from the paper)
    """

    def __init__(self, temperature: float = 0.07) -> None:
        super().__init__()
        self.temperature = temperature

    def forward(
        self,
        features: torch.Tensor,   # (B, d) ℓ₂-normalised embeddings
        labels: torch.Tensor,     # (B,)  class indices
    ) -> torch.Tensor:
        B = features.shape[0]
        device = features.device

        if B < 2:
            return features.new_tensor(0.0)

        # ℓ₂ normalise (in case caller did not)
        features = F.normalize(features, dim=1)

        # Similarity matrix S ∈ ℝ^{B×B}
        sim = features @ features.T / self.temperature    # (B, B)

        # Mask out self-similarities on the diagonal
        eye  = torch.eye(B, device=device, dtype=torch.bool)
        mask_self = ~eye                                   # True = keep

        # Positive mask: same label, not self
        labels_eq = labels.unsqueeze(0) == labels.unsqueeze(1)   # (B, B)
        pos_mask  = labels_eq & mask_self                          # (B, B)

        # Log-sum-exp denominator over all non-self pairs
        # For numerical stability subtract max per row
        sim_masked = sim.masked_fill(eye, -1e9)                   # ignore self
        log_denom  = torch.logsumexp(sim_masked, dim=1, keepdim=True)  # (B,1)

        # Hard-negative weights w_{i,a} = softmax(sim_{i,a}) over all a≠i
        hard_neg_weights = F.softmax(sim_masked, dim=1)           # (B, B)

        # Per-anchor SCL loss
        loss = torch.tensor(0.0, device=device)
        n_valid = 0

        for i in range(B):
            pos_idx = pos_mask[i].nonzero(as_tuple=True)[0]
            if len(pos_idx) == 0:
                continue   # no positive for this anchor in the batch

            # Log-probability for each positive
            log_probs = sim[i][pos_idx] - log_denom[i]           # (|P(i)|,)

            # Hard-negative re-weighting: multiply log-probs by their weight
            weights = hard_neg_weights[i][pos_idx]                # (|P(i)|,)

            loss = loss - (weights * log_probs).sum() / len(pos_idx)
            n_valid += 1

        return loss / max(n_valid, 1)


# ──────────────────────────────────────────────────────────────────────────────
# Combined fine-tuning loss
# ──────────────────────────────────────────────────────────────────────────────

class FineTuningLoss(nn.Module):
    """
    L = L_CE  +  λ · L_SCL     (λ = 0.5, Eq. 8)

    Parameters
    ----------
    lambda_scl      : weight on the contrastive term (0.5)
    class_weights   : optional tensor of shape (num_classes,) for CE
    temperature_scl : contrastive temperature τ (0.07)
    """

    def __init__(
        self,
        lambda_scl: float = 0.5,
        class_weights: torch.Tensor | None = None,
        temperature_scl: float = 0.07,
    ) -> None:
        super().__init__()
        self.lambda_scl = lambda_scl
        self.ce  = nn.CrossEntropyLoss(weight=class_weights)
        self.scl = SupervisedContrastiveLoss(temperature=temperature_scl)

    def forward(
        self,
        logits:   torch.Tensor,    # (B, num_classes) — raw CE logits
        features: torch.Tensor,    # (B, embed_dim)   — ℓ₂-norm contrastive embeds
        labels:   torch.Tensor,    # (B,) integer class labels
    ) -> dict[str, torch.Tensor]:
        loss_ce  = self.ce(logits, labels)
        loss_scl = self.scl(features, labels)
        total    = loss_ce + self.lambda_scl * loss_scl
        return {
            "loss":      total,
            "loss_ce":   loss_ce,
            "loss_scl":  loss_scl,
        }


# ──────────────────────────────────────────────────────────────────────────────
# MVM pretraining losses (Stage 1, Eqs. 3–5)
# ──────────────────────────────────────────────────────────────────────────────

class MVMLoss(nn.Module):
    """
    Masked Volume Modelling pretraining loss.

    L_pre = L_MVM  +  β_cm · L_cm  +  β_reg · L_reg
          β_cm = β_reg = 0.5

    All three terms are mean squared error over masked patches.
    """

    def __init__(self, beta_cm: float = 0.5, beta_reg: float = 0.5) -> None:
        super().__init__()
        self.beta_cm  = beta_cm
        self.beta_reg = beta_reg

    def forward(
        self,
        pred_mvm:  torch.Tensor,   # (B, N_masked, patch_dim) — within-modality
        true_mvm:  torch.Tensor,
        pred_cm:   torch.Tensor,   # (B, N_all, patch_dim)    — cross-modal
        true_cm:   torch.Tensor,
        pred_reg:  torch.Tensor,   # (B, N_roi, patch_dim)    — region-mask
        true_reg:  torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        loss_mvm = F.mse_loss(pred_mvm, true_mvm)
        loss_cm  = F.mse_loss(pred_cm,  true_cm)
        loss_reg = F.mse_loss(pred_reg, true_reg)
        total    = loss_mvm + self.beta_cm * loss_cm + self.beta_reg * loss_reg
        return {
            "loss":      total,
            "loss_mvm":  loss_mvm,
            "loss_cm":   loss_cm,
            "loss_reg":  loss_reg,
        }


# ──────────────────────────────────────────────────────────────────────────────
# Class-weight helper
# ──────────────────────────────────────────────────────────────────────────────

def sqrt_frequency_weights(
    class_counts: dict[str, int],
    class_order: list[str],
) -> torch.Tensor:
    """
    Square-root inverse-frequency class weights, normalised so mean = 1.
    Used for all baselines and NeuroFM-AX (Section 4.4).

    Example
    -------
    counts = {"HC": 80, "PD": 96, "Prodromal": 56, "SWEDD": 42}
    weights = sqrt_frequency_weights(counts, ["HC","PD","Prodromal","SWEDD"])
    """
    counts = torch.tensor([class_counts[c] for c in class_order], dtype=torch.float)
    weights = 1.0 / counts.sqrt()
    weights = weights / weights.mean()
    return weights
