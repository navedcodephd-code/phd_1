"""
utils/reproducibility.py
-------------------------
Seed control helpers used throughout the codebase.

Table 7 in the paper reports 10-fold CV means under seed 42 only.
Seeds 17 and 2024 are used only as a stability check.
"""

from __future__ import annotations

import os
import random

import numpy as np
import torch


CANONICAL_SEED = 42
STABILITY_SEEDS = [42, 17, 2024]


def seed_everything(seed: int = CANONICAL_SEED) -> None:
    """
    Set all relevant random seeds for full reproducibility.
    Covers: Python random, NumPy, PyTorch (CPU + all GPUs), CUDA.
    """
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # Ensure deterministic algorithms (may slow down training)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark     = False
    print(f"  [reproducibility] All seeds set to {seed}")


"""
utils/checkpoint.py
--------------------
Checkpoint selection rule:
  Primary   criterion: lowest validation cross-entropy loss
  Tiebreaker          : highest validation balanced accuracy

  The held-out test set is NEVER used for checkpoint selection.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import torch


@dataclass
class CheckpointEntry:
    epoch:            int
    val_loss:         float
    val_bal_accuracy: float
    filepath:         Path


class BestCheckpointKeeper:
    """
    Tracks the best checkpoint according to the selection rule:
      (1) min val_loss  →  primary criterion
      (2) max val_balanced_accuracy  →  tiebreaker

    Saves only the current best checkpoint to disk (keeps storage small).
    """

    def __init__(
        self,
        checkpoint_dir: Path,
        model_name: str = "neurofmax",
        keep_last_n: int = 1,
    ) -> None:
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.model_name  = model_name
        self.keep_last_n = keep_last_n
        self.best: Optional[CheckpointEntry] = None
        self.history: list[CheckpointEntry] = []

    def is_better(self, entry: CheckpointEntry) -> bool:
        """Return True if `entry` is better than the current best."""
        if self.best is None:
            return True
        # Primary: lower val_loss
        if entry.val_loss < self.best.val_loss - 1e-6:
            return True
        # Tiebreaker: higher balanced accuracy
        if abs(entry.val_loss - self.best.val_loss) <= 1e-6:
            return entry.val_bal_accuracy > self.best.val_bal_accuracy
        return False

    def save(
        self,
        epoch: int,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        val_loss: float,
        val_bal_accuracy: float,
        extra: Optional[dict] = None,
    ) -> Optional[Path]:
        """
        Save checkpoint if this epoch is the best so far.
        Returns the path if saved, else None.
        """
        entry = CheckpointEntry(
            epoch=epoch,
            val_loss=val_loss,
            val_bal_accuracy=val_bal_accuracy,
            filepath=self.checkpoint_dir / f"{self.model_name}_best.pt",
        )

        if not self.is_better(entry):
            return None

        self.best = entry
        self.history.append(entry)

        state = {
            "epoch":            epoch,
            "model_state_dict": model.state_dict(),
            "optimizer_state":  optimizer.state_dict(),
            "val_loss":         val_loss,
            "val_bal_accuracy": val_bal_accuracy,
            "selection_rule":   "min_val_loss; tiebreak: max_val_balanced_accuracy",
        }
        if extra:
            state.update(extra)

        torch.save(state, entry.filepath)
        print(
            f"  [checkpoint] Saved epoch {epoch:3d}  "
            f"val_loss={val_loss:.5f}  val_bal_acc={val_bal_accuracy:.4f}  "
            f"→ {entry.filepath.name}"
        )
        return entry.filepath

    def load_best(self, model: torch.nn.Module, device: str = "cpu") -> dict:
        """Load the best checkpoint into `model` and return the full state dict."""
        if self.best is None:
            raise RuntimeError("No checkpoint saved yet.")
        state = torch.load(self.best.filepath, map_location=device)
        model.load_state_dict(state["model_state_dict"])
        print(
            f"  [checkpoint] Loaded best checkpoint: epoch {state['epoch']}  "
            f"val_loss={state['val_loss']:.5f}"
        )
        return state

    def save_log(self, log_path: Optional[Path] = None) -> None:
        """Write checkpoint selection log to JSON for reproducibility."""
        log_path = log_path or (self.checkpoint_dir / "checkpoint_log.json")
        log = [
            {
                "epoch":            e.epoch,
                "val_loss":         e.val_loss,
                "val_bal_accuracy": e.val_bal_accuracy,
                "filepath":         str(e.filepath),
            }
            for e in self.history
        ]
        log_path.write_text(json.dumps(log, indent=2))
