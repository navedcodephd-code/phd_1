# Changelog

All notable changes to NeuroFM-AX are documented in this file. The current
version of this repository corresponds to manuscript revision v2.4 (paper file
`NeuroFM-AX_paper_revised_v2_4.docx`).

The format roughly follows [Keep a Changelog](https://keepachangelog.com/).

## [v2.4] — Revision in response to reviewer comments

### Fixed
- **[Comment 1]** Site C fold size in Table 5 corrected to **16** (was 24).
  The corrected fold gives exactly `15 / 16 = 93.75%`, consistent with an
  integer confusion matrix. A regression test
  (`tests/test_confusion_matrices.py::test_site_c_is_fixed_at_sixteen`) now
  blocks any future revision that reintroduces the erroneous fold size.
- **[Comment 3]** Figures renumbered so that t-SNE (Section 5.4) is Figure 10
  and the ablation studies (Section 5.5) are Figure 11. All in-text references
  (including the previous `Figure 10b` for the masking-ratio ablation, which is
  now `Figure 11b`) have been updated; alt-text descriptions in the document
  XML have been corrected.
- **[Comment 4]** Section 4.1 now states *six publicly available sources
  covering four imaging modalities*: UK Biobank, ADNI, OASIS-3, IXI (T1/FLAIR),
  a multi-site NM-MRI collection, and PPMI baseline DAT-SPECT.

### Added
- **[Comment 2]** Standard deviations across folds added to Table 5 for
  Macro-F1 (± 2.51), Macro-AUC (± 0.012), and SWEDD recall (± 6.37).
- **[Comment 5]** Section 4.3 explicitly states that Table 7 reports
  mean ± SD across ten CV folds within seed 42, and that the across-seed
  variability (≤ 0.7 percentage points across seeds 42, 17, 2024) is reported
  separately in Section 5.7.
- **[Comment 6]** Reproducibility section in Section 4.3 enumerates the eight
  items released here:
  1. Subject-level patient-ID splits (`data/splits/{train,val,test}*.txt`,
     `data/splits/loso/site_{A,B,C}_test.txt`).
  2. Preprocessing pipeline as executable scripts with exact parameters
     (`src/preprocessing/pipeline.py`).
  3. Stage 1 pretraining, Stage 2 LoRA fine-tuning, temperature scaling, and
     bootstrap evaluation code (`src/`).
  4. Eight baseline implementations re-trained under matched protocol
     (`src/baselines/`).
  5. Three random seeds hard-coded in `configs/seeds.yaml`.
  6. YAML configuration files for every hyperparameter in Table 3 and
     Section 4.4 (`configs/`).
  7. Checkpoint-selection rule (`src/utils/checkpoint.py`).
  8. Bootstrap CI and paired-bootstrap test scripts
     (`src/evaluation/bootstrap.py`, `src/evaluation/loso.py`).
- MIT licence (`LICENSE`).
- `Dockerfile` pinning PyTorch 2.3, MONAI 1.3, ANTsPy 0.4, FSL 6.0.
- Unit-test suite (`tests/`) that verifies all confusion matrices reproduce
  the integer counts shown in Figure 6a and Table 5.

## [v2.3] — Prior submission

Initial submission with the full reproducibility narrative but containing the
Site C fold-size inconsistency, single-figure-number collision between t-SNE
and ablations, and ambiguous seed reporting in Section 4.3.
