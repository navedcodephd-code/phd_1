# NeuroFM-AX

**An Anatomy-Conditioned Cross-Modal Foundation Model with Low-Rank Adaptation for Calibrated Differential Diagnosis of Parkinson's Disease**

Naved Ahmad, Ihtiram Raza Khan, Suraiya Parveen, Siddhartha Sankar Biswas
Department of Computer Science and Engineering, Jamia Hamdard University, New Delhi, India

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch 2.3](https://img.shields.io/badge/PyTorch-2.3-red.svg)](https://pytorch.org/)

This repository contains the complete training, evaluation, and reproducibility code for the paper
**"NeuroFM-AX: An Anatomy-Conditioned Cross-Modal Foundation Model with Low-Rank Adaptation
for Calibrated Differential Diagnosis of Parkinson's Disease"**, accepted at the *International
Journal of Intelligent Engineering and Systems*.

A permanent archived release with citable DOI is available on Zenodo (DOI to be added on
camera-ready acceptance).

---

## Table of Contents
1. [Overview](#overview)
2. [Repository Layout](#repository-layout)
3. [Installation](#installation)
4. [Data Access](#data-access)
5. [Reproducing the Paper](#reproducing-the-paper)
6. [Random Seeds and Determinism](#random-seeds-and-determinism)
7. [Checkpoint-Selection Rule](#checkpoint-selection-rule)
8. [Docker](#docker)
9. [Citation](#citation)
10. [License](#license)

---

## Overview

NeuroFM-AX is a two-stage framework:

- **Stage 1** pretrains a 3D ViT-Base backbone (L=12, d=768, 86 M parameters) with
  anatomy-conditioned tokenization and cross-modal Masked Volume Modeling on T1, T2-FLAIR,
  NM-MRI, and DAT-SPECT.
- **Stage 2** freezes the backbone and trains 0.52 M LoRA parameters (≈0.6% of backbone) on
  the PPMI four-class differential diagnosis: HC, PD, Prodromal, SWEDD.

On the strictly held-out PPMI test set (75 patients), the model reaches **71/75 = 94.67%**
accuracy with 95% bootstrap CI [89.33, 98.67], macro-AUC 0.992, and ECE 0.028 after
temperature scaling.

---

## Repository Layout

```
neurofm-ax/
├── configs/                 # YAML hyperparameter configs (every value in Table 3)
│   ├── pretrain.yaml
│   ├── finetune_neurofmax.yaml
│   └── baselines/           # one YAML per baseline in Table 3
├── data/
│   └── splits/              # subject-level patient-ID splits for Tables 2 and 5
│       ├── train_274.txt
│       ├── val_69.txt
│       ├── test_75.txt
│       └── loso/            # leave-one-site-out folds for Table 5
├── src/
│   ├── models/              # NeuroFM-AX backbone, anatomy tokenizer, LoRA, heads
│   ├── baselines/           # 8 baseline implementations from Table 3
│   ├── preprocessing/       # FSL-BET, ANTs N4, FLIRT, z-score, gamma, CLAHE, bilateral
│   ├── evaluation/          # confusion matrix, bootstrap CIs, paired-bootstrap tests
│   └── utils/               # seeding, logging, registry
├── scripts/                 # entry points: pretrain.sh, finetune.sh, evaluate.sh
├── tests/                   # unit tests verifying the confusion matrices reproduce
├── docs/                    # extra documentation and architecture diagrams
├── Dockerfile
├── requirements.txt
├── LICENSE
└── README.md
```

---

## Installation

### From source (Python 3.10+)

```bash
git clone https://github.com/navedcodephd-code/phd_1.git
cd phd_1
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
pip install -e .
```

### External binary tools

Preprocessing requires:

- **FSL 6.0** (provides `bet`) — https://fsl.fmrib.ox.ac.uk
- **ANTs 2.5** (provides `N4BiasFieldCorrection`) — https://github.com/ANTsX/ANTs
- **FLIRT** (bundled with FSL) for 12-DOF affine MNI registration

The Dockerfile in this repository pins compatible versions of all of the above.

---

## Data Access

This repository does **not** redistribute imaging data. Data must be obtained from the
original providers under their respective data-use agreements:

| Cohort      | URL                                  | Used in        |
|-------------|--------------------------------------|----------------|
| PPMI        | https://www.ppmi-info.org            | Fine-tuning + DAT-SPECT pretraining |
| UK Biobank  | https://www.ukbiobank.ac.uk          | T1/T2-FLAIR pretraining             |
| ADNI        | https://adni.loni.usc.edu            | T1/T2-FLAIR pretraining             |
| OASIS-3     | https://www.oasis-brains.org         | T1/T2-FLAIR pretraining             |
| IXI         | https://brain-development.org/ixi-dataset | T1 pretraining                |
| NM-MRI corpus | Multi-site research collection (see Section 4.1) | NM-MRI pretraining        |

After data is downloaded, populate paths in `configs/pretrain.yaml` and
`configs/finetune_neurofmax.yaml`.

---

## Reproducing the Paper

Every table and figure in the paper can be reproduced from the commands below.

### Stage 1 — Pretraining

```bash
# 800 epochs on 4 NVIDIA A100 GPUs, ~6 days wall-clock
bash scripts/pretrain.sh configs/pretrain.yaml
```

### Stage 2 — LoRA fine-tuning (seed 42, used for Table 7 and Figure 6a)

```bash
bash scripts/finetune.sh configs/finetune_neurofmax.yaml --seed 42
```

### 10-fold cross-validation under three seeds (Section 5.7)

```bash
for seed in 42 17 2024; do
  bash scripts/cv10fold.sh configs/finetune_neurofmax.yaml --seed $seed
done
```

### Leave-one-site-out evaluation (Table 5)

```bash
bash scripts/loso.sh configs/finetune_neurofmax.yaml
```

### Baselines (Table 7)

```bash
for cfg in configs/baselines/*.yaml; do
  bash scripts/finetune.sh "$cfg" --seed 42
done
```

### Bootstrap CIs and paired-bootstrap tests (Sections 5.2–5.7)

```bash
python -m src.evaluation.bootstrap --predictions outputs/test_predictions.npz --B 1000
python -m src.evaluation.paired_bootstrap \
    --a outputs/cv_neurofmax.npz --b outputs/cv_swinclassifier.npz --B 1000
```

### One-command full reproduction

```bash
make reproduce-all     # runs every step above; expects 4× A100 and ~7 days
```

---

## Random Seeds and Determinism

The three random seeds used in the paper are hard-coded in version-controlled YAMLs:

```
configs/seeds.yaml
  primary: 42        # Table 7, Figure 6a, Table 4, Figure 8, Figure 9
  replicate_1: 17    # Section 5.7 cross-seed variability
  replicate_2: 2024  # Section 5.7 cross-seed variability
```

Determinism flags (`torch.backends.cudnn.deterministic = True`,
`torch.use_deterministic_algorithms(True)`) are enabled in `src/utils/seeding.py`. Across-seed
variability is ≤ 0.7 percentage points (Section 5.7) and is **not** folded into the SDs
shown in Table 7 (which are across-fold within seed 42).

---

## Checkpoint-Selection Rule

The exact rule used in the paper:

> Lowest validation negative log-likelihood under early stopping with patience 10 on
> validation balanced accuracy.

Implemented in `src/utils/checkpoint.py::select_best_checkpoint`. The corresponding YAML
section is:

```yaml
checkpoint_selection:
  monitor: val_balanced_accuracy
  patience: 10
  mode: max
  save_metric: val_nll
  save_mode: min
```

---

## Docker

```bash
docker build -t neurofm-ax:1.0 .
docker run --gpus all -v /path/to/data:/data -v $PWD:/workspace neurofm-ax:1.0 \
    bash scripts/finetune.sh configs/finetune_neurofmax.yaml --seed 42
```

---

## Citation

```bibtex
@article{ahmad2025neurofmax,
  title   = {NeuroFM-AX: An Anatomy-Conditioned Cross-Modal Foundation Model with
             Low-Rank Adaptation for Calibrated Differential Diagnosis of Parkinson's Disease},
  author  = {Ahmad, Naved and Khan, Ihtiram Raza and Parveen, Suraiya and Biswas, Siddhartha Sankar},
  journal = {International Journal of Intelligent Engineering and Systems},
  year    = {2025},
  doi     = {10.22266/ijies2019.xxxx.xx}
}
```

---

## License

This code is released under the **MIT License** (see `LICENSE`). The trained model weights,
when released on Zenodo, will be available under CC-BY 4.0. Data redistribution is governed
by each source cohort's data-use agreement.

---

## Contact

For questions: navedahmad786.0786@gmail.com
