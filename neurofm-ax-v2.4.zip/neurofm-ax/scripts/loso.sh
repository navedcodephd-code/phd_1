#!/usr/bin/env bash
# Leave-one-site-out evaluation reproducing Table 5.
# Three sites are held out in turn: Site A (largest, N=28), Site B (mid-size,
# N=18), Site C (smallest, N=16, corrected per reviewer comment 1).
set -euo pipefail

CFG="${1:-configs/finetune_neurofmax.yaml}"
SEED="${2:-42}"

for site in A B C; do
    OUT="outputs/loso/site_${site}"
    mkdir -p "$OUT"
    python -m src.train --config "$CFG" --seed "$SEED" \
        --output-dir "$OUT" --loso-holdout "$site"
done

python -m src.evaluation.loso \
    --splits-dir data/splits/loso \
    --predictions-dir outputs/loso \
    --output-json outputs/loso/summary.json
