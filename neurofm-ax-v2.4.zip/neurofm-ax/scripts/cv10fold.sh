#!/usr/bin/env bash
# 10-fold patient-level cross-validation on the 274-scan training partition.
# Reproduces Table 7 (within seed 42) and Section 5.7 (across seeds 42/17/2024).
# Usage:
#   bash scripts/cv10fold.sh configs/finetune_neurofmax.yaml --seed 42
set -euo pipefail

CFG="${1:-configs/finetune_neurofmax.yaml}"
shift
SEED=42
while [[ $# -gt 0 ]]; do
    case "$1" in
        --seed) SEED="$2"; shift 2 ;;
        *) shift ;;
    esac
done

for fold in 0 1 2 3 4 5 6 7 8 9; do
    OUT="outputs/cv10fold/seed${SEED}/fold${fold}"
    mkdir -p "$OUT"
    python -m src.train --config "$CFG" --seed "$SEED" \
        --output-dir "$OUT" --cv-fold "$fold" --cv-total 10
done

python -m src.evaluation.aggregate_cv \
    --root "outputs/cv10fold/seed${SEED}" \
    --output "outputs/cv10fold/seed${SEED}/summary.json"
