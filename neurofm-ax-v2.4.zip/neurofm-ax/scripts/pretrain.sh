#!/usr/bin/env bash
# Stage 1 pretraining entry script (Section 4.4).
# Usage: bash scripts/pretrain.sh configs/pretrain.yaml
set -euo pipefail

CFG="${1:-configs/pretrain.yaml}"
OUT="${2:-outputs/pretrain}"
mkdir -p "$OUT"

torchrun --nproc-per-node=4 -m src.pretrain \
    --config "$CFG" \
    --output-dir "$OUT" \
    "${@:3}"
