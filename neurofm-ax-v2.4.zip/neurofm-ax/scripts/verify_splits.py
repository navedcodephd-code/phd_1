"""Verifies subject-level disjointness of every patient split.

Enforces the leakage controls described in Section 4.1 of the manuscript:
  - train_274, val_69, test_75 are subject-level disjoint.
  - Every LOSO test split is a subset of the full PPMI cohort.
  - No subject in the pretraining T1/FLAIR corpus appears in test_75.

Hash-based subject deduplication uses SHA-256 (Section 4.1).
"""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path


def load_ids(path: Path) -> set[str]:
    ids = set()
    if not path.exists():
        return ids
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        ids.add(line)
    return ids


def hash_id(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:16]


def main(splits_root: Path = Path("data/splits")) -> int:
    train = load_ids(splits_root / "train_274.txt")
    val = load_ids(splits_root / "val_69.txt")
    test = load_ids(splits_root / "test_75.txt")

    issues = 0
    for a, b, name in [
        (train, val, "train_274 vs val_69"),
        (train, test, "train_274 vs test_75"),
        (val, test, "val_69 vs test_75"),
    ]:
        overlap = a & b
        if overlap:
            print(f"FAIL: subject-level overlap in {name}: {sorted(overlap)}")
            issues += 1
        else:
            print(f"OK:   no overlap in {name}")

    # LOSO consistency
    loso_root = splits_root / "loso"
    for site, expected in [("A", 28), ("B", 18), ("C", 16)]:
        ids = load_ids(loso_root / f"site_{site}_test.txt")
        if len(ids) != expected:
            print(f"FAIL: site {site} should have {expected} IDs but has {len(ids)}")
            issues += 1
        else:
            print(f"OK:   site {site} has {expected} IDs (matches Table 5)")

    # Pretraining-vs-test leakage check (only runs if a corpus listing exists)
    pretrain_listing = splits_root / "pretraining_subjects.txt"
    if pretrain_listing.exists():
        pretrain = load_ids(pretrain_listing)
        leaks = test & pretrain
        if leaks:
            print(f"FAIL: {len(leaks)} test subjects in pretraining corpus")
            issues += 1
        else:
            print("OK:   no pretraining/test leakage detected")
    else:
        print("note: pretraining_subjects.txt not provided; skipping leakage check")

    return issues


if __name__ == "__main__":
    sys.exit(min(main(), 1))
