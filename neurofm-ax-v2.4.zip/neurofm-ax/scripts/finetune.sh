#!/usr/bin/env bash
# Stage 2 LoRA fine-tuning entry script.
# Usage:
#   bash scripts/finetune.sh configs/finetune_neurofmax.yaml [--seed 42]
#   bash scripts/finetune.sh configs/baselines/swinclassifier.yaml --seed 17
set -euo pipefail

CFG="${1:-configs/finetune_neurofmax.yaml}"
shift
SEED=42
OUT="outputs/finetune_$(basename "$CFG" .yaml)_seed${SEED}"
mkdir -p "$OUT"

python -m src.train --config "$CFG" --seed "$SEED" --output-dir "$OUT" "$@"
