"""Checkpoint-selection rule (Section 4.3):

Lowest validation negative log-likelihood under early stopping with patience 10
on validation balanced accuracy.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import torch


@dataclass
class CheckpointSelector:
    """Tracks best NLL under early stopping on balanced accuracy."""
    patience: int = 10
    monitor_mode: str = "max"                 # for balanced accuracy
    best_balanced_acc: float = float("-inf")
    best_nll: float = float("inf")
    epochs_without_improve: int = 0
    best_path: Path | None = None

    def update(self, *, val_balanced_acc: float, val_nll: float,
               model_state: dict, save_dir: Path, epoch: int) -> str:
        """Returns one of: 'saved', 'no_improve', 'stop'."""
        save_dir.mkdir(parents=True, exist_ok=True)
        improved_acc = val_balanced_acc > self.best_balanced_acc
        if improved_acc:
            self.best_balanced_acc = val_balanced_acc
            self.epochs_without_improve = 0
        else:
            self.epochs_without_improve += 1

        # Save when val_nll improves AND we are still within patience.
        if val_nll < self.best_nll:
            self.best_nll = val_nll
            ckpt_path = save_dir / "checkpoint_best.pt"
            torch.save({"epoch": epoch, "state_dict": model_state,
                        "val_nll": val_nll,
                        "val_balanced_acc": val_balanced_acc}, ckpt_path)
            self.best_path = ckpt_path
            return "saved"

        if self.epochs_without_improve >= self.patience:
            return "stop"
        return "no_improve"


def select_best_checkpoint(directory: Path) -> Path:
    """Return the path of the lowest-NLL checkpoint in ``directory``."""
    best = None
    best_nll = float("inf")
    for ckpt in directory.glob("*.pt"):
        state = torch.load(ckpt, map_location="cpu")
        nll = float(state.get("val_nll", float("inf")))
        if nll < best_nll:
            best_nll = nll
            best = ckpt
    if best is None:
        raise FileNotFoundError(f"No checkpoints found in {directory}")
    return best
