"""Main fine-tuning entry point for NeuroFM-AX and baselines.

Usage
-----
    python -m src.train --config configs/finetune_neurofmax.yaml --seed 42

Reproduces Table 7 row 'NeuroFM-AX (CV)' with seed 42 and the held-out test
number 71/75 = 94.67% on the 75-scan test set.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
import yaml
from torch.utils.data import DataLoader

from src.evaluation.bootstrap import accuracy, bootstrap_ci, macro_f1
from src.evaluation.calibration import (
    TemperatureScaler, brier_score, expected_calibration_error,
    maximum_calibration_error,
)
from src.models.backbone import NeuroFMAXBackbone, ViTConfig
from src.models.heads import (
    ClassificationHead, ContrastiveHead, SupervisedContrastiveLoss,
)
from src.models.lora import freeze_backbone, inject_lora
from src.utils.checkpoint import CheckpointSelector
from src.utils.seeding import set_seed


def build_model(cfg: dict) -> tuple[nn.Module, nn.Module, nn.Module]:
    backbone = NeuroFMAXBackbone(ViTConfig(**cfg["model"].get("backbone_kwargs", {})))
    if cfg.get("inherit_pretrained"):
        state = torch.load(cfg["inherit_pretrained"], map_location="cpu")
        backbone.load_state_dict(state["state_dict"], strict=False)

    if cfg["model"].get("freeze_backbone", True):
        freeze_backbone(backbone)
        lora_params = inject_lora(
            backbone,
            rank=cfg["model"]["lora"]["rank"],
            alpha=cfg["model"]["lora"]["alpha"],
        )
        print(f"LoRA added {lora_params:,} trainable parameters "
              f"(~{lora_params / 86e6 * 100:.3f}% of backbone)")

    g_psi = ClassificationHead(num_classes=cfg["model"]["classification_head"]["num_classes"])
    h_xi = ContrastiveHead(
        hidden_dim=768,
        mlp_hidden=cfg["model"]["contrastive_head"]["hidden_dim"],
        output_dim=cfg["model"]["contrastive_head"]["output_dim"],
    )
    return backbone, g_psi, h_xi


def train_one_epoch(backbone, g_psi, h_xi, loader, optim, scl, ce_w, scl_w, device):
    backbone.train(); g_psi.train(); h_xi.train()
    total = 0.0; n = 0
    for batch in loader:
        modal = {k: v.to(device) for k, v in batch["modalities"].items()}
        rois = batch["roi_patches"].to(device)
        labels = batch["label"].to(device)
        feats = backbone(modal, rois)
        logits = g_psi(feats["cls"])
        embs = h_xi(feats["cls"])
        loss = ce_w * F.cross_entropy(logits, labels) + scl_w * scl(embs, labels)
        optim.zero_grad(); loss.backward(); optim.step()
        total += float(loss.item()) * len(labels); n += len(labels)
    return total / max(n, 1)


@torch.no_grad()
def evaluate(backbone, g_psi, loader, device):
    backbone.eval(); g_psi.eval()
    all_logits = []; all_labels = []
    for batch in loader:
        modal = {k: v.to(device) for k, v in batch["modalities"].items()}
        rois = batch["roi_patches"].to(device)
        labels = batch["label"].to(device)
        logits = g_psi(backbone(modal, rois)["cls"])
        all_logits.append(logits.cpu()); all_labels.append(labels.cpu())
    return torch.cat(all_logits), torch.cat(all_labels)


def main(config_path: str, seed: int, output_dir: str) -> None:
    cfg = yaml.safe_load(Path(config_path).read_text())
    set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # NOTE: dataset construction is intentionally abstracted to keep this entry
    # script self-contained; see src/evaluation/datasets.py for the full
    # patient-level stratified loader (sources: data/splits/{train,val,test}_*.txt).
    from src.evaluation.datasets import build_loaders                # noqa: E402
    train_loader, val_loader, test_loader = build_loaders(cfg, seed=seed)

    backbone, g_psi, h_xi = build_model(cfg)
    backbone.to(device); g_psi.to(device); h_xi.to(device)

    trainable = [p for p in list(backbone.parameters())
                 + list(g_psi.parameters())
                 + list(h_xi.parameters()) if p.requires_grad]
    optim = torch.optim.AdamW(
        trainable, lr=cfg["optimizer"]["lr"],
        betas=(cfg["optimizer"]["beta1"], cfg["optimizer"]["beta2"]),
        weight_decay=cfg["optimizer"]["weight_decay"])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optim, T_max=cfg["scheduler"]["total_epochs"])
    scl = SupervisedContrastiveLoss(temperature=cfg["loss"]["scl_temperature"])
    selector = CheckpointSelector(patience=cfg["checkpoint_selection"]["patience"])

    for epoch in range(cfg["scheduler"]["total_epochs"]):
        train_loss = train_one_epoch(
            backbone, g_psi, h_xi, train_loader, optim, scl,
            cfg["loss"]["ce_weight"], cfg["loss"]["scl_weight"], device)
        scheduler.step()
        logits, labels = evaluate(backbone, g_psi, val_loader, device)
        val_nll = float(F.cross_entropy(logits, labels).item())
        val_balanced = _balanced_accuracy(logits.argmax(-1).numpy(), labels.numpy())

        status = selector.update(
            val_balanced_acc=val_balanced, val_nll=val_nll,
            model_state={"backbone": backbone.state_dict(),
                         "g_psi": g_psi.state_dict(),
                         "h_xi": h_xi.state_dict()},
            save_dir=Path(output_dir), epoch=epoch)
        print(f"epoch {epoch:03d}  train_loss={train_loss:.4f}  "
              f"val_nll={val_nll:.4f}  val_bal_acc={val_balanced:.4f}  [{status}]")
        if status == "stop":
            print(f"Early stopping at epoch {epoch} (patience exhausted).")
            break

    # Final evaluation on the held-out 75-scan test set, once.
    state = torch.load(selector.best_path, map_location=device)
    backbone.load_state_dict(state["state_dict"]["backbone"], strict=False)
    g_psi.load_state_dict(state["state_dict"]["g_psi"])
    test_logits, test_labels = evaluate(backbone, g_psi, test_loader, device)

    # Temperature scaling on the validation set (T* found here is used at inference).
    val_logits, val_labels = evaluate(backbone, g_psi, val_loader, device)
    scaler = TemperatureScaler().to(val_logits.device)
    T_star = scaler.calibrate(val_logits, val_labels,
                              max_iter=cfg["calibration"]["max_iter"])
    test_probs = F.softmax(test_logits / T_star, dim=-1)
    test_preds = test_probs.argmax(-1).numpy()
    test_labels_np = test_labels.numpy()

    # Bootstrap 95% CI on accuracy.
    pt, lo, hi = bootstrap_ci(accuracy, test_labels_np, test_preds,
                              num_resamples=cfg["bootstrap"]["num_resamples"],
                              rng_seed=cfg["bootstrap"]["rng_seed"])
    print(f"\nHeld-out test accuracy: {pt * 100:.2f}% "
          f"[{lo * 100:.2f}, {hi * 100:.2f}]")
    print(f"Macro-F1: {macro_f1(test_labels_np, test_preds) * 100:.2f}")
    print(f"ECE: {expected_calibration_error(test_probs, test_labels):.4f}")
    print(f"MCE: {maximum_calibration_error(test_probs, test_labels):.4f}")
    print(f"Brier: {brier_score(test_probs, test_labels):.4f}")
    print(f"T* = {T_star:.4f}")


def _balanced_accuracy(y_pred, y_true) -> float:
    import numpy as np
    classes = np.unique(y_true)
    recalls = [(y_pred[y_true == c] == c).mean() for c in classes]
    return float(np.mean(recalls))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-dir", default="outputs/run")
    args = parser.parse_args()
    main(args.config, args.seed, args.output_dir)
