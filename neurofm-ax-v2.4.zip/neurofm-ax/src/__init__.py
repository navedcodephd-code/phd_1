"""NeuroFM-AX: anatomy-conditioned cross-modal foundation model for PD."""
__version__ = "2.4.0"
