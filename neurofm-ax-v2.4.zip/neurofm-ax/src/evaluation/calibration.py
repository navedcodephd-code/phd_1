"""Temperature scaling, ECE / MCE / Brier (Section 3.4, Equations 9-11).

p_k(x) = exp(u_k / T) / sum_j exp(u_j / T)        (9)
ECE    = sum_m |B_m|/N |acc(B_m) - conf(B_m)|     (10)
MCE    = max_m |acc(B_m) - conf(B_m)|             (10)
Brier  = 1/N sum_i sum_k (p_k(x_i) - 1[y_i = k])^2 (11)
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class TemperatureScaler(nn.Module):
    """Single scalar T > 0 learned on the validation split, fit by L-BFGS."""

    def __init__(self, initial_T: float = 1.0):
        super().__init__()
        self.log_T = nn.Parameter(torch.log(torch.tensor(initial_T)))

    @property
    def T(self) -> torch.Tensor:
        return self.log_T.exp()

    def forward(self, logits: torch.Tensor) -> torch.Tensor:
        return logits / self.T

    @torch.no_grad()
    def calibrate(self, logits: torch.Tensor, labels: torch.Tensor,
                  max_iter: int = 50) -> float:
        """Minimise validation NLL; T* found here is used at inference."""
        self.log_T.requires_grad_(True)
        opt = torch.optim.LBFGS([self.log_T], lr=0.1, max_iter=max_iter,
                                line_search_fn="strong_wolfe")

        def closure():
            opt.zero_grad()
            with torch.enable_grad():
                loss = F.cross_entropy(logits / self.T, labels)
                loss.backward()
            return loss

        with torch.enable_grad():
            opt.step(closure)
        return float(self.T.item())


def expected_calibration_error(probs: torch.Tensor, labels: torch.Tensor,
                               num_bins: int = 10) -> float:
    """ECE (Equation 10) with M = 10 equal-width bins."""
    confidences, predictions = probs.max(dim=-1)
    accuracies = predictions.eq(labels).float()
    boundaries = torch.linspace(0.0, 1.0, num_bins + 1, device=probs.device)
    ece = torch.tensor(0.0, device=probs.device)
    n = probs.shape[0]
    for i in range(num_bins):
        lo, hi = boundaries[i], boundaries[i + 1]
        in_bin = (confidences > lo) & (confidences <= hi)
        if not in_bin.any():
            continue
        bin_acc = accuracies[in_bin].mean()
        bin_conf = confidences[in_bin].mean()
        ece = ece + (in_bin.float().sum() / n) * (bin_acc - bin_conf).abs()
    return float(ece)


def maximum_calibration_error(probs: torch.Tensor, labels: torch.Tensor,
                              num_bins: int = 10) -> float:
    """MCE (Equation 10)."""
    confidences, predictions = probs.max(dim=-1)
    accuracies = predictions.eq(labels).float()
    boundaries = torch.linspace(0.0, 1.0, num_bins + 1, device=probs.device)
    gaps = []
    for i in range(num_bins):
        lo, hi = boundaries[i], boundaries[i + 1]
        in_bin = (confidences > lo) & (confidences <= hi)
        if not in_bin.any():
            continue
        gaps.append((accuracies[in_bin].mean() - confidences[in_bin].mean()).abs())
    return float(max(gaps).item()) if gaps else 0.0


def brier_score(probs: torch.Tensor, labels: torch.Tensor,
                num_classes: int = 4) -> float:
    """Multi-class Brier score (Equation 11)."""
    one_hot = F.one_hot(labels, num_classes=num_classes).float()
    return float(((probs - one_hot) ** 2).sum(dim=-1).mean().item())
