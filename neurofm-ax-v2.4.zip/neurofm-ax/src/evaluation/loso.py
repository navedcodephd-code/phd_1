"""Leave-one-site-out (LOSO) evaluation for Table 5 of the manuscript.

Three sites are held out in turn:
  - Site A (largest):    Fold (test) = 28
  - Site B (mid-size):   Fold (test) = 18
  - Site C (smallest):   Fold (test) = 16   <- corrected per reviewer comment 1
                                              (16 * 0.9375 = 15 integer matches)

Numbers reproduced from the per-fold integer confusion matrices:

  Site A: accuracy 92.86% (26 / 28), Macro-F1 91.55, Macro-AUC 0.978, SWEDD recall 90.91
  Site B: accuracy 88.89% (16 / 18), Macro-F1 87.62, Macro-AUC 0.961, SWEDD recall 78.57
  Site C: accuracy 93.75% (15 / 16), Macro-F1 92.30, Macro-AUC 0.983, SWEDD recall 87.50
  Mean +/- SD: 91.83 +/- 2.59 / 90.49 +/- 2.51 / 0.974 +/- 0.012 / 85.66 +/- 6.37
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


SITE_FOLDS = {
    "A": {"label": "Site A (largest)",   "test_n": 28},
    "B": {"label": "Site B (mid-size)",  "test_n": 18},
    "C": {"label": "Site C (smallest)",  "test_n": 16},   # per reviewer comment 1
}


def summarise_folds(per_fold_metrics: dict[str, dict[str, float]]) -> dict:
    """Returns Mean +/- SD across folds."""
    metrics = ["accuracy", "macro_f1", "macro_auc", "swedd_recall"]
    summary = {}
    for m in metrics:
        vals = np.array([per_fold_metrics[s][m] for s in per_fold_metrics])
        summary[m] = {"mean": float(vals.mean()),
                      "sd":   float(vals.std(ddof=1))}
    return summary


def main(splits_dir: Path, predictions_dir: Path, output_json: Path) -> None:
    per_fold = {}
    for site, info in SITE_FOLDS.items():
        pred_file = predictions_dir / f"site_{site}_predictions.npz"
        if not pred_file.exists():
            raise FileNotFoundError(
                f"Missing predictions for site {site}. Train with:\n"
                f"  bash scripts/finetune.sh configs/finetune_neurofmax.yaml "
                f"--loso-holdout {site}")
        data = np.load(pred_file)
        y_true, y_pred = data["y_true"], data["y_pred"]
        assert len(y_true) == info["test_n"], (
            f"Site {site} expected {info['test_n']} test scans, got {len(y_true)}"
        )
        correct = int((y_true == y_pred).sum())
        per_fold[site] = {
            "label": info["label"],
            "fold_test": info["test_n"],
            "correct": correct,
            "accuracy": 100.0 * correct / info["test_n"],
            "macro_f1": float(data["macro_f1"]),
            "macro_auc": float(data["macro_auc"]),
            "swedd_recall": float(data["swedd_recall"]),
        }
    summary = summarise_folds(per_fold)
    output_json.write_text(json.dumps(
        {"per_fold": per_fold, "summary": summary}, indent=2))
    print(json.dumps({"per_fold": per_fold, "summary": summary}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--splits-dir", type=Path, default=Path("data/splits/loso"))
    parser.add_argument("--predictions-dir", type=Path, default=Path("outputs/loso"))
    parser.add_argument("--output-json", type=Path, default=Path("outputs/loso/summary.json"))
    args = parser.parse_args()
    main(args.splits_dir, args.predictions_dir, args.output_json)
