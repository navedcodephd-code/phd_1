"""Bootstrap 95% CIs and paired-bootstrap tests (Sections 5.2-5.7).

For each metric mu, we draw B = 1000 bootstrap samples S^b of size N with
replacement from the test set and report the empirical 95% percentile interval

    CI_95%(mu) = [mu_{(0.025 B)}, mu_{(0.975 B)}]

for accuracy, balanced accuracy, per-class precision, recall, F1, AUC, ECE,
MCE, and Brier.

Paired-bootstrap tests compare two methods on matched fold-level accuracies.
"""

from __future__ import annotations

from typing import Callable

import numpy as np


def bootstrap_ci(
    metric_fn: Callable[[np.ndarray, np.ndarray], float],
    y_true: np.ndarray,
    y_pred: np.ndarray,
    num_resamples: int = 1000,
    ci_level: float = 0.95,
    rng_seed: int = 42,
) -> tuple[float, float, float]:
    """Return (point_estimate, lower, upper) for the given metric.

    Example
    -------
    >>> acc = bootstrap_ci(lambda y, p: (y == p).mean(),
    ...                    y_true=labels, y_pred=preds)
    """
    rng = np.random.default_rng(rng_seed)
    n = len(y_true)
    point = float(metric_fn(y_true, y_pred))
    samples = np.empty(num_resamples, dtype=np.float64)
    for b in range(num_resamples):
        idx = rng.integers(0, n, size=n)
        samples[b] = metric_fn(y_true[idx], y_pred[idx])
    alpha = (1.0 - ci_level) / 2.0
    lower = float(np.quantile(samples, alpha))
    upper = float(np.quantile(samples, 1.0 - alpha))
    return point, lower, upper


def paired_bootstrap(
    metric_fn: Callable[[np.ndarray, np.ndarray], float],
    y_true: np.ndarray,
    y_pred_a: np.ndarray,
    y_pred_b: np.ndarray,
    num_resamples: int = 1000,
    rng_seed: int = 42,
) -> dict[str, float]:
    """Two-sided paired bootstrap test on metric(A) - metric(B).

    Returns the observed difference, the bootstrap 95% CI for the difference,
    and a two-sided p-value.
    """
    rng = np.random.default_rng(rng_seed)
    n = len(y_true)
    diff_obs = float(metric_fn(y_true, y_pred_a) - metric_fn(y_true, y_pred_b))
    diffs = np.empty(num_resamples, dtype=np.float64)
    for b in range(num_resamples):
        idx = rng.integers(0, n, size=n)
        diffs[b] = (metric_fn(y_true[idx], y_pred_a[idx])
                    - metric_fn(y_true[idx], y_pred_b[idx]))
    lower = float(np.quantile(diffs, 0.025))
    upper = float(np.quantile(diffs, 0.975))
    # Two-sided p: probability of zero or opposite-sign difference under H_0
    if diff_obs >= 0:
        p = float(2.0 * (diffs <= 0).mean())
    else:
        p = float(2.0 * (diffs >= 0).mean())
    p = min(max(p, 1.0 / num_resamples), 1.0)
    return {"diff": diff_obs, "ci_low": lower, "ci_high": upper, "p_value": p}


def paired_bootstrap_folds(
    fold_accuracies_a: np.ndarray,
    fold_accuracies_b: np.ndarray,
    num_resamples: int = 1000,
    rng_seed: int = 42,
) -> dict[str, float]:
    """Paired bootstrap on fold-level accuracies (used in Table 7 / Section 5.7)."""
    assert fold_accuracies_a.shape == fold_accuracies_b.shape
    rng = np.random.default_rng(rng_seed)
    k = len(fold_accuracies_a)
    diffs = fold_accuracies_a - fold_accuracies_b
    obs = float(diffs.mean())
    boot = np.empty(num_resamples, dtype=np.float64)
    for b in range(num_resamples):
        idx = rng.integers(0, k, size=k)
        boot[b] = diffs[idx].mean()
    lower = float(np.quantile(boot, 0.025))
    upper = float(np.quantile(boot, 0.975))
    if obs >= 0:
        p = float(2.0 * (boot <= 0).mean())
    else:
        p = float(2.0 * (boot >= 0).mean())
    p = min(max(p, 1.0 / num_resamples), 1.0)
    return {"diff": obs, "ci_low": lower, "ci_high": upper, "p_value": p}


# Convenience metric closures ---------------------------------------------------

def accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float((y_true == y_pred).mean())


def macro_f1(y_true: np.ndarray, y_pred: np.ndarray, num_classes: int = 4) -> float:
    f1s = []
    for c in range(num_classes):
        tp = float(((y_pred == c) & (y_true == c)).sum())
        fp = float(((y_pred == c) & (y_true != c)).sum())
        fn = float(((y_pred != c) & (y_true == c)).sum())
        p = tp / (tp + fp) if tp + fp > 0 else 0.0
        r = tp / (tp + fn) if tp + fn > 0 else 0.0
        f1s.append(2 * p * r / (p + r) if p + r > 0 else 0.0)
    return float(np.mean(f1s))
