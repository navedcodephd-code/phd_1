"""Baseline implementations re-trained under matched protocol (Table 3 + Section 4.4).

All eight baselines see the same training set, validation set, augmentation,
schedule family, early-stopping (patience 10 on validation balanced accuracy),
and budget (50 fine-tuning epochs at matched compute).

Random seeds are fixed at 42; the four strongest baselines (Scratch ViT, ConvKAN,
SwinClassifier, Full fine-tuning) are additionally re-trained under seeds 17 and
2024 for the cross-seed variability check in Section 5.7.
"""

from __future__ import annotations

import torch
import torch.nn as nn


def build_baseline(name: str, num_classes: int = 4) -> nn.Module:
    """Construct one of the eight baselines from Table 3."""
    name = name.lower()
    if name == "lenet5":
        return LeNet5MidAxial(num_classes)
    if name in {"unet_classifier", "unet_cls_head"}:
        return UNet3DClassifier(num_classes)
    if name in {"resnet18_3d", "resnet18"}:
        return ResNet3D18(num_classes)
    if name == "attentionlunet":
        return AttentionLUNet(num_classes)
    if name in {"scratch_vit", "vit_scratch"}:
        return ScratchViT3D(num_classes)
    if name == "convkan":
        return ConvKAN3D(num_classes)
    if name == "swinclassifier":
        return SwinClassifier(num_classes)
    if name in {"full_finetuning", "full_ft"}:
        return FullFinetuneViT(num_classes)
    raise KeyError(f"Unknown baseline: {name}")


class LeNet5MidAxial(nn.Module):
    """LeNet-5 on the mid-axial 2D slice. ~1.6 M parameters."""

    def __init__(self, num_classes: int = 4):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 6, kernel_size=5), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(6, 16, kernel_size=5), nn.ReLU(), nn.MaxPool2d(2),
        )
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((5, 5)),
            nn.Flatten(),
            nn.Linear(16 * 25, 120), nn.ReLU(),
            nn.Linear(120, 84), nn.ReLU(),
            nn.Linear(84, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Extract mid-axial slice.
        z = x.shape[-3] // 2
        x = x[..., z, :, :]
        return self.classifier(self.features(x))


class UNet3DClassifier(nn.Module):
    """3D U-Net encoder + global average pool + linear head. ~17.4 M parameters."""

    def __init__(self, num_classes: int = 4, base_channels: int = 32):
        super().__init__()
        c = base_channels
        self.enc = nn.Sequential(
            _conv3d_block(1, c),     _conv3d_block(c, 2 * c, stride=2),
            _conv3d_block(2 * c, 4 * c, stride=2), _conv3d_block(4 * c, 8 * c, stride=2),
        )
        self.gap = nn.AdaptiveAvgPool3d(1)
        self.fc = nn.Linear(8 * c, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc(self.gap(self.enc(x)).flatten(1))


def _conv3d_block(c_in: int, c_out: int, stride: int = 1) -> nn.Module:
    return nn.Sequential(
        nn.Conv3d(c_in, c_out, kernel_size=3, stride=stride, padding=1, bias=False),
        nn.BatchNorm3d(c_out), nn.ReLU(inplace=True),
        nn.Conv3d(c_out, c_out, kernel_size=3, padding=1, bias=False),
        nn.BatchNorm3d(c_out), nn.ReLU(inplace=True),
    )


class ResNet3D18(nn.Module):
    """3D ResNet-18 trained from scratch. ~33.2 M parameters."""

    def __init__(self, num_classes: int = 4):
        super().__init__()
        from monai.networks.nets import ResNet
        self.net = ResNet(block="basic", layers=[2, 2, 2, 2],
                          block_inplanes=[64, 128, 256, 512],
                          n_input_channels=1, num_classes=num_classes,
                          spatial_dims=3)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class AttentionLUNet(nn.Module):
    """Reference [12] — LeNet-5 + U-Net + attention. ~13.8 M parameters."""

    def __init__(self, num_classes: int = 4):
        super().__init__()
        self.unet_encoder = UNet3DClassifier(num_classes=num_classes,
                                             base_channels=16)
        self.attn = nn.MultiheadAttention(embed_dim=128, num_heads=4,
                                          batch_first=True)
        self.fc = nn.Linear(128, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feat = self.unet_encoder.enc(x)
        b, c = feat.shape[:2]
        tokens = feat.reshape(b, c, -1).transpose(1, 2)
        attended, _ = self.attn(tokens, tokens, tokens)
        return self.fc(attended.mean(dim=1))


class ScratchViT3D(nn.Module):
    """3D ViT-Base trained from scratch. ~86.0 M parameters."""

    def __init__(self, num_classes: int = 4):
        super().__init__()
        from src.models.backbone import NeuroFMAXBackbone, ViTConfig
        self.backbone = NeuroFMAXBackbone(ViTConfig())
        self.head = nn.Linear(768, num_classes)

    def forward(self, modal_volumes, roi_patches):
        return self.head(self.backbone(modal_volumes, roi_patches)["cls"])


class ConvKAN3D(nn.Module):
    """Reference [11] — 3D Convolutional Kolmogorov-Arnold Network. ~21.7 M params."""

    def __init__(self, num_classes: int = 4):
        super().__init__()
        # Spline-based KAN convolutional approximation.
        c = 32
        self.stem = nn.Sequential(
            nn.Conv3d(1, c, 3, padding=1), nn.GELU(),
            nn.Conv3d(c, 2 * c, 3, stride=2, padding=1), nn.GELU(),
            nn.Conv3d(2 * c, 4 * c, 3, stride=2, padding=1), nn.GELU(),
            nn.Conv3d(4 * c, 8 * c, 3, stride=2, padding=1), nn.GELU(),
        )
        self.spline = nn.Sequential(
            nn.Conv3d(8 * c, 8 * c, 3, padding=1, groups=8 * c), nn.GELU(),
            nn.Conv3d(8 * c, 8 * c, 1), nn.GELU(),
        )
        self.gap = nn.AdaptiveAvgPool3d(1)
        self.fc = nn.Linear(8 * c, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.spline(self.stem(x))
        return self.fc(self.gap(h).flatten(1))


class SwinClassifier(nn.Module):
    """Reference [14] — Swin-UNETR encoder + linear head. ~88.0 M parameters."""

    def __init__(self, num_classes: int = 4):
        super().__init__()
        from monai.networks.nets import SwinUNETR
        self.encoder = SwinUNETR(img_size=(96, 96, 96), in_channels=1,
                                 out_channels=num_classes, feature_size=48,
                                 use_checkpoint=True)
        self.gap = nn.AdaptiveAvgPool3d(1)
        self.fc = nn.Linear(48 * 16, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feats = self.encoder.swinViT(x, normalize=True)[-1]
        return self.fc(self.gap(feats).flatten(1))


class FullFinetuneViT(nn.Module):
    """Pretrained NeuroFM-AX backbone with all 86 M params unfrozen."""

    def __init__(self, num_classes: int = 4):
        super().__init__()
        from src.models.backbone import NeuroFMAXBackbone, ViTConfig
        self.backbone = NeuroFMAXBackbone(ViTConfig())
        self.head = nn.Linear(768, num_classes)

    def forward(self, modal_volumes, roi_patches):
        return self.head(self.backbone(modal_volumes, roi_patches)["cls"])
