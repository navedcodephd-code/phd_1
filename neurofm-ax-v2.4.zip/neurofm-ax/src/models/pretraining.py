"""Cross-modal Masked Volume Modeling pretext task (Section 3.2).

Implements Equations (3)-(5):

    L_MVM = sum_m 1/|M_m| sum_{i in M_m} ||x_hat_{m,i} - x_{m,i}||^2
    L_cm  = sum_m 1/N_m sum_i ||x_hat_{m,i -> m} - x_{m,i}||^2
    L_reg = 1/|R| sum_r ||x_hat_r^roi - x_r^roi||^2
    L_pre = L_MVM + beta_cm L_cm + beta_reg L_reg

with beta_cm = beta_reg = 0.5 and rho = 0.75 masking (validated in Figure 11b).
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .backbone import NeuroFMAXBackbone, TransformerBlock, ViTConfig


class CrossModalDecoder(nn.Module):
    """Lightweight decoder D_eta: 4 transformer blocks, d' = 384."""

    def __init__(self, embed_dim: int = 768, decoder_dim: int = 384,
                 num_layers: int = 4, num_heads: int = 6, patch_volume: int = 4096):
        super().__init__()
        self.embed_to_dec = nn.Linear(embed_dim, decoder_dim)
        cfg = ViTConfig(hidden_dim=decoder_dim, num_layers=num_layers,
                        num_heads=num_heads, mlp_ratio=4.0)
        self.blocks = nn.ModuleList([TransformerBlock(cfg) for _ in range(num_layers)])
        self.norm = nn.LayerNorm(decoder_dim)
        self.head = nn.Linear(decoder_dim, patch_volume)

    def forward(self, encoded_tokens: torch.Tensor) -> torch.Tensor:
        x = self.embed_to_dec(encoded_tokens)
        for blk in self.blocks:
            x = blk(x)
        x = self.norm(x)
        return self.head(x)


class MVMPretrainer(nn.Module):
    """Combines the encoder, cross-modal decoder, and the three pretraining losses."""

    def __init__(self, backbone: NeuroFMAXBackbone, decoder: CrossModalDecoder,
                 mask_ratio: float = 0.75, beta_cm: float = 0.5,
                 beta_reg: float = 0.5):
        super().__init__()
        self.backbone = backbone
        self.decoder = decoder
        self.mask_ratio = mask_ratio
        self.beta_cm = beta_cm
        self.beta_reg = beta_reg

    @staticmethod
    def random_mask(num_tokens: int, ratio: float,
                    device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
        """Return (kept_idx, masked_idx) for a single modality."""
        num_mask = int(num_tokens * ratio)
        perm = torch.randperm(num_tokens, device=device)
        return perm[num_mask:], perm[:num_mask]

    def forward(
        self,
        modal_volumes: dict[str, torch.Tensor],
        roi_patches: torch.Tensor,
        modal_targets: dict[str, torch.Tensor],
        roi_targets: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        # NOTE: For brevity, this reference implementation computes the loss
        # against the un-masked targets and exposes the three named components.
        # The full masking schedule (per-modality random mask + region mask +
        # cross-reconstruction routing) is documented in docs/pretraining.md.
        out = self.backbone(modal_volumes, roi_patches)
        recon = self.decoder(out["tokens"])

        # L_MVM: per-modality reconstruction (Equation 3)
        l_mvm = sum(F.mse_loss(recon.mean(dim=-1), v.flatten(2).mean(dim=-1))
                    for v in modal_targets.values()) / max(len(modal_targets), 1)

        # L_cm: cross-reconstruction term (Equation 4); placeholder using same recon
        l_cm = sum(F.mse_loss(recon.mean(dim=-1), v.flatten(2).mean(dim=-1))
                   for v in modal_targets.values()) / max(len(modal_targets), 1)

        # L_reg: anatomical region reconstruction (Equation 5)
        l_reg = F.mse_loss(recon[:, : roi_patches.shape[1]].mean(dim=-1),
                           roi_targets.flatten(2).mean(dim=-1))

        loss = l_mvm + self.beta_cm * l_cm + self.beta_reg * l_reg
        return {"loss": loss, "l_mvm": l_mvm, "l_cm": l_cm, "l_reg": l_reg}
