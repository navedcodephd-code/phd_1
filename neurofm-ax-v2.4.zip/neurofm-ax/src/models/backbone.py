"""NeuroFM-AX 3D Vision Transformer backbone with anatomy-conditioned tokenization.

Implements Equations (1) and (2) of the manuscript.

Backbone: 3D ViT-Base, L=12, d=768, 12 attention heads, 86 M parameters.
Tokenization combines 12 anatomical ROI tokens (32^3, trilinear-interpolated) and
N_m ~ 1600 global 16^3 tokens per modality.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class ViTConfig:
    """Configuration for the 3D ViT-Base backbone (Section 3.2)."""
    hidden_dim: int = 768
    num_layers: int = 12
    num_heads: int = 12
    mlp_ratio: float = 4.0
    dropout: float = 0.0
    patch_size: tuple[int, int, int] = (16, 16, 16)
    roi_patch_size: tuple[int, int, int] = (32, 32, 32)
    num_roi_tokens: int = 12
    modalities: tuple[str, ...] = ("t1", "t2flair", "nm_mri", "dat_spect")


class PatchEmbed3D(nn.Module):
    """Per-modality 3D patch embedding E_m (Equation 1)."""

    def __init__(self, in_channels: int, hidden_dim: int, patch_size: Sequence[int]):
        super().__init__()
        self.proj = nn.Conv3d(in_channels, hidden_dim, kernel_size=patch_size,
                              stride=patch_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, C, D, H, W) -> (B, N_tokens, hidden)
        x = self.proj(x)
        x = x.flatten(2).transpose(1, 2)
        return x


class ROITokenEmbed(nn.Module):
    """Anatomy-conditioned ROI tokenizer.

    For each of the 12 PD-relevant subcortical structures (left/right substantia
    nigra, putamen, caudate, globus pallidus, thalamus, locus coeruleus), the
    region is resampled to (32, 32, 32) by trilinear interpolation in MNI space
    and linearly projected to a d-dimensional embedding.
    """

    def __init__(self, num_rois: int, hidden_dim: int,
                 roi_patch_size: Sequence[int], in_channels: int = 1):
        super().__init__()
        self.num_rois = num_rois
        in_dim = int(in_channels * math.prod(roi_patch_size))
        self.proj = nn.Linear(in_dim, hidden_dim)
        self.roi_patch_size = tuple(roi_patch_size)

    def forward(self, roi_patches: torch.Tensor) -> torch.Tensor:
        # roi_patches: (B, num_rois, C, 32, 32, 32)
        b, r = roi_patches.shape[:2]
        flat = roi_patches.reshape(b, r, -1)
        return self.proj(flat)


class MultiHeadAttention(nn.Module):
    """Multi-head self-attention with optional LoRA injection (Equation 2)."""

    def __init__(self, hidden_dim: int, num_heads: int, dropout: float = 0.0):
        super().__init__()
        assert hidden_dim % num_heads == 0
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        self.q = nn.Linear(hidden_dim, hidden_dim)
        self.k = nn.Linear(hidden_dim, hidden_dim)
        self.v = nn.Linear(hidden_dim, hidden_dim)
        self.proj = nn.Linear(hidden_dim, hidden_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, n, _ = x.shape
        q = self.q(x).view(b, n, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k(x).view(b, n, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v(x).view(b, n, self.num_heads, self.head_dim).transpose(1, 2)
        attn = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        attn = F.softmax(attn, dim=-1)
        attn = self.dropout(attn)
        out = (attn @ v).transpose(1, 2).reshape(b, n, -1)
        return self.proj(out)


class TransformerBlock(nn.Module):
    """Pre-norm Transformer block (Equation 2)."""

    def __init__(self, cfg: ViTConfig):
        super().__init__()
        self.norm1 = nn.LayerNorm(cfg.hidden_dim)
        self.attn = MultiHeadAttention(cfg.hidden_dim, cfg.num_heads, cfg.dropout)
        self.norm2 = nn.LayerNorm(cfg.hidden_dim)
        hidden = int(cfg.hidden_dim * cfg.mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(cfg.hidden_dim, hidden),
            nn.GELU(),
            nn.Dropout(cfg.dropout),
            nn.Linear(hidden, cfg.hidden_dim),
            nn.Dropout(cfg.dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


class NeuroFMAXBackbone(nn.Module):
    """Cross-modal 3D ViT-Base backbone with anatomy-conditioned tokenization."""

    def __init__(self, cfg: ViTConfig):
        super().__init__()
        self.cfg = cfg
        self.cls_token = nn.Parameter(torch.zeros(1, 1, cfg.hidden_dim))
        nn.init.trunc_normal_(self.cls_token, std=0.02)

        # Per-modality patch embeddings (Equation 1)
        self.patch_embeds = nn.ModuleDict({
            m: PatchEmbed3D(1, cfg.hidden_dim, cfg.patch_size)
            for m in cfg.modalities
        })
        # Modality-type embeddings e_m^mod
        self.modality_embeds = nn.ParameterDict({
            m: nn.Parameter(torch.zeros(1, 1, cfg.hidden_dim)) for m in cfg.modalities
        })
        for p in self.modality_embeds.values():
            nn.init.trunc_normal_(p, std=0.02)

        # Anatomy-conditioned ROI tokenizer
        self.roi_embed = ROITokenEmbed(
            cfg.num_roi_tokens, cfg.hidden_dim, cfg.roi_patch_size
        )

        # Learnable 3D positional embedding p_{m,i}
        self.pos_embed = nn.Parameter(torch.zeros(1, 8192, cfg.hidden_dim))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        # L=12 Transformer blocks
        self.blocks = nn.ModuleList(
            [TransformerBlock(cfg) for _ in range(cfg.num_layers)]
        )
        self.norm = nn.LayerNorm(cfg.hidden_dim)

    def tokenize(
        self,
        modal_volumes: dict[str, torch.Tensor],
        roi_patches: torch.Tensor,
    ) -> tuple[torch.Tensor, dict[str, slice]]:
        """Produce input-layer tokens (Equation 1) with modality + position
        embeddings.

        Returns the concatenated token sequence and per-modality slices for
        downstream masking and reconstruction.
        """
        tokens = []
        offset = 0
        modality_slices: dict[str, slice] = {}

        roi_tok = self.roi_embed(roi_patches)
        tokens.append(roi_tok)
        modality_slices["roi"] = slice(offset, offset + roi_tok.shape[1])
        offset += roi_tok.shape[1]

        for m in self.cfg.modalities:
            if m not in modal_volumes:
                continue
            patches = self.patch_embeds[m](modal_volumes[m])
            patches = patches + self.modality_embeds[m]
            tokens.append(patches)
            modality_slices[m] = slice(offset, offset + patches.shape[1])
            offset += patches.shape[1]

        x = torch.cat(tokens, dim=1)
        x = x + self.pos_embed[:, : x.shape[1], :]
        return x, modality_slices

    def forward(
        self,
        modal_volumes: dict[str, torch.Tensor],
        roi_patches: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        b = roi_patches.shape[0]
        x, _slices = self.tokenize(modal_volumes, roi_patches)
        cls_tok = self.cls_token.expand(b, -1, -1)
        x = torch.cat([cls_tok, x], dim=1)
        for blk in self.blocks:
            x = blk(x)
        x = self.norm(x)
        return {"cls": x[:, 0], "tokens": x[:, 1:]}
