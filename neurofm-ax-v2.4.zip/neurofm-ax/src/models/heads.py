"""Classification head g_psi and contrastive projection head h_xi (Section 3.3).

Implements Equations (7) and (8) of the manuscript.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


class ClassificationHead(nn.Module):
    """g_psi: linear map from [CLS] token to 4 logits (HC, PD, Prodromal, SWEDD)."""

    def __init__(self, hidden_dim: int = 768, num_classes: int = 4):
        super().__init__()
        self.fc = nn.Linear(hidden_dim, num_classes)

    def forward(self, cls_token: torch.Tensor) -> torch.Tensor:
        return self.fc(cls_token)


class ContrastiveHead(nn.Module):
    """h_xi: two-layer MLP producing an L2-normalised 128-d embedding v."""

    def __init__(self, hidden_dim: int = 768, mlp_hidden: int = 512,
                 output_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(hidden_dim, mlp_hidden),
            nn.GELU(),
            nn.Linear(mlp_hidden, output_dim),
        )

    def forward(self, cls_token: torch.Tensor) -> torch.Tensor:
        z = self.net(cls_token)
        return F.normalize(z, p=2, dim=-1)


class SupervisedContrastiveLoss(nn.Module):
    """L_SCL (Equation 7), with hard-negative re-weighting w_{i,a}.

    Since SWEDD and Prodromal scans are visually close to PD, this objective
    sharpens the boundary between PD and its mimics by re-weighting negatives
    by anchor similarity, so hard negatives dominate the gradient.
    """

    def __init__(self, temperature: float = 0.07, hard_negative_reweight: bool = True):
        super().__init__()
        self.tau = temperature
        self.hnr = hard_negative_reweight

    def forward(self, embeddings: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        # embeddings: (B, d), labels: (B,)
        b = embeddings.shape[0]
        sim = (embeddings @ embeddings.t()) / self.tau

        # Numerical stability
        sim_max, _ = sim.max(dim=1, keepdim=True)
        sim = sim - sim_max.detach()

        # Build mask M_{ip} = 1 iff y_p = y_i and p != i
        label_eq = labels.unsqueeze(0) == labels.unsqueeze(1)
        self_mask = torch.eye(b, dtype=torch.bool, device=embeddings.device)
        pos_mask = label_eq & ~self_mask
        valid = (~self_mask).float()

        exp_sim = torch.exp(sim) * valid
        if self.hnr:
            # Anchor-similarity re-weighting: w_{i,a} = softmax(sim_{i,a})
            w = exp_sim / (exp_sim.sum(dim=1, keepdim=True).clamp_min(1e-12))
            denom = (exp_sim * (1.0 + w)).sum(dim=1, keepdim=True)
        else:
            denom = exp_sim.sum(dim=1, keepdim=True)

        log_prob = sim - torch.log(denom.clamp_min(1e-12))

        # Average over positives P(i)
        pos_count = pos_mask.float().sum(dim=1).clamp_min(1.0)
        loss = -(log_prob * pos_mask.float()).sum(dim=1) / pos_count
        return loss.mean()
