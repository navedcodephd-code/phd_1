"""Low-Rank Adaptation (LoRA) for the frozen 3D ViT-Base backbone.

Implements Equation (6) of the manuscript:

    W = W_0 + Delta W,   Delta W = B A,   h = W_0 x + (alpha / r) B A x

with A in R^{r x d}, B in R^{k x r}, r << min(d, k). We initialise A ~ N(0, sigma^2)
and B = 0, set r = 8 and alpha = 16, and apply LoRA to W_q, W_v and both MLP
projections. The 3D ViT-Base backbone has 86 M parameters; LoRA adds 0.52 M trainable
parameters, approximately 0.6% (0.605%, computed as 0.52 / 86.0) of the backbone.
"""

from __future__ import annotations

from typing import Iterable

import torch
import torch.nn as nn


class LoRALinear(nn.Module):
    """Replaces nn.Linear with W_0 (frozen) + (alpha/r) B A (trainable)."""

    def __init__(self, base: nn.Linear, rank: int = 8, alpha: float = 16.0,
                 init_std: float = 0.02):
        super().__init__()
        self.base = base
        # Freeze the original weights
        for p in self.base.parameters():
            p.requires_grad = False

        in_features, out_features = base.in_features, base.out_features
        self.rank = rank
        self.scaling = alpha / rank
        self.A = nn.Parameter(torch.zeros(rank, in_features))
        self.B = nn.Parameter(torch.zeros(out_features, rank))
        nn.init.normal_(self.A, std=init_std)
        # B is initialised to zero so Delta W starts at zero.

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.base(x) + self.scaling * (x @ self.A.t()) @ self.B.t()


def inject_lora(
    backbone: nn.Module,
    rank: int = 8,
    alpha: float = 16.0,
    targets: Iterable[str] = ("q", "v", "0", "3"),  # W_q, W_v, mlp.0, mlp.3
) -> int:
    """Inject LoRA adapters into every matching nn.Linear submodule.

    Returns the number of trainable parameters added.
    """
    targets = tuple(targets)
    added = 0
    for parent_name, parent in list(backbone.named_modules()):
        for child_name, child in list(parent.named_children()):
            if not isinstance(child, nn.Linear):
                continue
            full = f"{parent_name}.{child_name}".strip(".")
            # Match attention Q/V projections and MLP fc1/fc2 layers.
            if not any(_match(full, t) for t in targets):
                continue
            lora = LoRALinear(child, rank=rank, alpha=alpha)
            setattr(parent, child_name, lora)
            added += lora.A.numel() + lora.B.numel()
    return added


def _match(name: str, target: str) -> bool:
    """Heuristic match for the four target sites named in the paper."""
    tail = name.split(".")[-1]
    if target == "q" and tail == "q":
        return True
    if target == "v" and tail == "v":
        return True
    # MLP is nn.Sequential(Linear, GELU, Dropout, Linear, Dropout): indices 0 and 3.
    if target in {"0", "3"} and tail == target and ".mlp." in f".{name}.":
        return True
    return False


def freeze_backbone(backbone: nn.Module) -> None:
    """Freeze every parameter that is not a LoRA adapter."""
    for n, p in backbone.named_parameters():
        if ".A" in n or ".B" in n:
            p.requires_grad = True
        else:
            p.requires_grad = False
