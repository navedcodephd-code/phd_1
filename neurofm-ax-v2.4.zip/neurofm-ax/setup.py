"""Installer for the NeuroFM-AX reproducibility package."""

from setuptools import find_packages, setup

setup(
    name="neurofm-ax",
    version="2.4.0",
    description=("Anatomy-conditioned cross-modal foundation model with low-rank "
                 "adaptation for calibrated differential diagnosis of Parkinson's "
                 "disease."),
    author="Naved Ahmad, Ihtiram Raza Khan, Suraiya Parveen, Siddhartha Sankar Biswas",
    author_email="navedahmad786.0786@gmail.com",
    url="https://github.com/navedcodephd-code/phd_1",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        line.strip() for line in open("requirements.txt")
        if line.strip() and not line.startswith("#")
    ],
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
    ],
)
