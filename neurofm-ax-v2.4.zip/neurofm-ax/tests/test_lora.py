"""Tests verifying paper-claimed parameter counts.

NeuroFM-AX trains approximately 0.6% (0.605% = 0.52 / 86.0) of the 86 M-parameter
backbone via LoRA with r = 8, alpha = 16 applied to W_q, W_v, and both MLP
projections.
"""

import torch.nn as nn

from src.models.backbone import NeuroFMAXBackbone, ViTConfig
from src.models.lora import freeze_backbone, inject_lora


def test_backbone_has_approximately_86m_parameters():
    backbone = NeuroFMAXBackbone(ViTConfig())
    total = sum(p.numel() for p in backbone.parameters())
    # Allow +/- 10% slack for embedding sizes that depend on token-budget
    # constants (positional embedding table size, modality embeddings).
    assert 70e6 < total < 110e6, f"Backbone has {total / 1e6:.1f} M parameters"


def test_lora_adds_trainable_only_around_06_percent():
    backbone = NeuroFMAXBackbone(ViTConfig())
    total = sum(p.numel() for p in backbone.parameters())
    freeze_backbone(backbone)
    added = inject_lora(backbone, rank=8, alpha=16.0,
                        targets=("q", "v", "0", "3"))
    # After freezing + injection, trainable params should be ~ 'added'.
    trainable = sum(p.numel() for p in backbone.parameters() if p.requires_grad)
    # The paper reports approximately 0.6% (0.605%, computed as 0.52 / 86.0).
    pct = trainable / total * 100
    assert 0.2 < pct < 1.5, f"LoRA fraction is {pct:.3f}% (expected ~0.6%)"
