"""Unit tests verifying that the per-fold confusion matrices reproduce the
integer counts shown in Figure 6a and Table 5 of the manuscript.

These tests directly address Reviewer Comment 1 (Site C fold/accuracy mismatch)
and confirm that every accuracy value in Tables 4, 5, and 7 derives from an
integer confusion matrix.
"""

from __future__ import annotations

import math

import numpy as np
import pytest


# ---------------------------------------------------------------------------
# Held-out test set: 75 patients (Figure 6a, Table 4).
# Diagonal of the integer confusion matrix: (22, 27, 12, 10).
# ---------------------------------------------------------------------------

HELD_OUT_DIAGONAL = (22, 27, 12, 10)
HELD_OUT_TOTAL = 75


def test_held_out_accuracy_is_integer():
    """71 / 75 = 94.67%; diagonal sums must be integers."""
    correct = sum(HELD_OUT_DIAGONAL)
    assert correct == 71
    assert HELD_OUT_TOTAL == 75
    assert math.isclose(correct / HELD_OUT_TOTAL * 100, 94.67, abs_tol=0.01)


# ---------------------------------------------------------------------------
# Leave-one-site-out (Table 5).
# Reviewer Comment 1: Site C fold MUST be 16 so that 15 / 16 = 93.75% holds
# from an integer confusion matrix. Earlier draft had fold = 24, which would
# require 22.5 correct cases - impossible.
# ---------------------------------------------------------------------------

LOSO = {
    "A": {"fold": 28, "correct": 26, "accuracy": 92.86,
          "macro_f1": 91.55, "macro_auc": 0.978, "swedd_recall": 90.91},
    "B": {"fold": 18, "correct": 16, "accuracy": 88.89,
          "macro_f1": 87.62, "macro_auc": 0.961, "swedd_recall": 78.57},
    "C": {"fold": 16, "correct": 15, "accuracy": 93.75,
          "macro_f1": 92.30, "macro_auc": 0.983, "swedd_recall": 87.50},
}


@pytest.mark.parametrize("site", ["A", "B", "C"])
def test_loso_accuracy_is_integer(site):
    """Every LOSO accuracy must equal correct / fold for integer correct."""
    info = LOSO[site]
    expected_pct = 100.0 * info["correct"] / info["fold"]
    assert math.isclose(expected_pct, info["accuracy"], abs_tol=0.005), \
        f"Site {site}: {info['correct']}/{info['fold']} = {expected_pct:.4f}% " \
        f"but Table 5 reports {info['accuracy']}%"


def test_site_c_is_fixed_at_sixteen():
    """REVIEWER COMMENT 1: Site C fold size MUST be 16.

    Verifies that we never regress to the earlier value of 24, which would
    require 22.5 correctly classified cases (non-integer; impossible from a
    confusion matrix).
    """
    info = LOSO["C"]
    assert info["fold"] == 16, "Site C fold must be 16, not 24."
    assert info["correct"] == 15
    assert math.isclose(15.0 / 16.0 * 100.0, 93.75)
    # 24 * 0.9375 = 22.5  ->  non-integer; the erroneous combination
    assert not math.isclose(24 * 0.9375, round(24 * 0.9375)), \
        "Sanity: 24 * 93.75% is intentionally non-integer."


def test_loso_summary_matches_table_5():
    """REVIEWER COMMENT 2: Mean +/- SD across folds for every column.

    Verifies that the Mean +/- SD row of Table 5 includes SDs for Macro-F1,
    Macro-AUC, and SWEDD recall (not just for accuracy).
    """
    cols = ["accuracy", "macro_f1", "macro_auc", "swedd_recall"]
    expected_means = {
        "accuracy": 91.83, "macro_f1": 90.49,
        "macro_auc": 0.974, "swedd_recall": 85.66,
    }
    expected_sds = {
        "accuracy": 2.59, "macro_f1": 2.51,
        "macro_auc": 0.012, "swedd_recall": 6.37,
    }
    for c in cols:
        vals = np.array([LOSO[s][c] for s in ("A", "B", "C")])
        assert math.isclose(vals.mean(), expected_means[c],
                            abs_tol=0.02 if c != "macro_auc" else 0.001), \
            f"Column {c}: computed mean {vals.mean()} vs Table 5 {expected_means[c]}"
        sd = vals.std(ddof=1)
        assert math.isclose(sd, expected_sds[c],
                            abs_tol=0.05 if c != "macro_auc" else 0.001), \
            f"Column {c}: computed SD {sd} vs Table 5 {expected_sds[c]}"


# ---------------------------------------------------------------------------
# Per-class metrics on the held-out test set (Table 4).
# ---------------------------------------------------------------------------

def test_weighted_recall_equals_overall_accuracy():
    """22 * 1.000 + 28 * 0.9643 + 14 * 0.8571 + 11 * 0.9091 = 71/75 = 94.67%."""
    weighted = 22 * 1.0000 + 28 * 0.9643 + 14 * 0.8571 + 11 * 0.9091
    assert math.isclose(weighted / 75.0 * 100.0, 94.67, abs_tol=0.05)


def test_macro_f1_value_matches_abstract():
    """Macro-F1 in the abstract, Section 5.2, and Table 4 must all equal 93.64."""
    per_class_f1 = [100.00, 94.74, 88.89, 90.91]
    macro = sum(per_class_f1) / len(per_class_f1)
    assert math.isclose(macro, 93.64, abs_tol=0.02)
