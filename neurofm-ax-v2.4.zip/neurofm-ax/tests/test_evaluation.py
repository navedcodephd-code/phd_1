"""Tests for bootstrap CIs, calibration metrics, and supervised contrastive loss."""

import numpy as np
import torch

from src.evaluation.bootstrap import accuracy, bootstrap_ci, paired_bootstrap_folds
from src.evaluation.calibration import (
    TemperatureScaler, brier_score, expected_calibration_error,
    maximum_calibration_error,
)
from src.models.heads import SupervisedContrastiveLoss


def test_bootstrap_ci_contains_point_estimate():
    rng = np.random.default_rng(42)
    n = 75
    y_true = rng.integers(0, 4, size=n)
    y_pred = y_true.copy()
    # Flip 4 predictions to simulate 71 / 75 accuracy.
    flips = rng.choice(n, size=4, replace=False)
    y_pred[flips] = (y_pred[flips] + 1) % 4
    pt, lo, hi = bootstrap_ci(accuracy, y_true, y_pred,
                              num_resamples=1000, rng_seed=42)
    assert lo <= pt <= hi
    assert abs(pt - (71 / 75)) < 1e-9


def test_paired_bootstrap_detects_significant_difference():
    rng = np.random.default_rng(0)
    a = 0.96 + 0.01 * rng.standard_normal(10)   # NeuroFM-AX CV: 96.0 +/- 0.8%
    b = 0.884 + 0.016 * rng.standard_normal(10)  # SwinClassifier: 88.4 +/- 1.6%
    res = paired_bootstrap_folds(a, b, num_resamples=2000, rng_seed=0)
    assert res["diff"] > 0
    # The paper reports p < 0.01 for NeuroFM-AX > SwinClassifier.
    assert res["p_value"] < 0.05


def test_temperature_scaling_reduces_ece():
    """ECE drops from 0.045 to 0.028 after T* = 0.91 (Section 5.3, Figure 8)."""
    torch.manual_seed(0)
    n, k = 500, 4
    logits = torch.randn(n, k) * 3.0
    labels = torch.argmax(logits + torch.randn_like(logits) * 0.5, dim=-1)
    probs_pre = torch.softmax(logits, dim=-1)
    ece_pre = expected_calibration_error(probs_pre, labels)
    scaler = TemperatureScaler()
    scaler.calibrate(logits, labels)
    probs_post = torch.softmax(logits / scaler.T, dim=-1)
    ece_post = expected_calibration_error(probs_post, labels)
    assert ece_post <= ece_pre + 1e-3


def test_mce_and_brier_are_in_range():
    torch.manual_seed(0)
    probs = torch.softmax(torch.randn(100, 4), dim=-1)
    labels = torch.randint(0, 4, (100,))
    mce = maximum_calibration_error(probs, labels)
    brier = brier_score(probs, labels)
    assert 0 <= mce <= 1
    assert 0 <= brier <= 2


def test_supervised_contrastive_loss_is_finite():
    torch.manual_seed(0)
    emb = torch.nn.functional.normalize(torch.randn(16, 128), dim=-1)
    labels = torch.tensor([0, 0, 1, 1, 2, 2, 3, 3] * 2)
    loss = SupervisedContrastiveLoss(temperature=0.07)(emb, labels)
    assert torch.isfinite(loss).item()
    assert loss.item() > 0
